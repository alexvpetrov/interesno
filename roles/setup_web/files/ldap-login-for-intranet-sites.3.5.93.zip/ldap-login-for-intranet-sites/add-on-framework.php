<?php
class MoAddonListContent
{

    function __construct()
    {

        define("MO_LDAP_ADDONS_CONTENT",serialize( array(

            "DIRECTORY_SYNC" =>      [
                'addonName'  => 'Sync Users LDAP Directory',
                'addonDescription'  => 'Synchronize Wordpress users with LDAP directory and vice versa. Schedules can be configured for the synchronization to run at a specific time and after a specific interval.',
                'addonPrice' => '169',
                'addonLicense' => 'wp_directory_sync_plan',

            ],
            "BUDDYPRESS_PROFILE_SYNC" =>      [
                'addonName'  => 'Sync BuddyPress Extended Profiles',
                'addonDescription'  => 'Integration with BuddyPress to sync extended profile of users with LDAP attributes upon login.',
                'addonPrice' => '149',
                'addonLicense' => 'wp_ldap_intranet_buddypress_extended_profiles_plan',

            ],
            "PASSWORD_SYNC" =>      [
                'addonName'  => 'Password Sync with LDAP',
                'addonDescription'  => 'Synchronize your Wordpress profile password with your LDAP user profile.',
                'addonPrice' => '99',
                'addonLicense' => 'ContactUs',

            ],
            "PROFILE_PICTURE_SYNC" =>      [
                'addonName'  => 'Profile Picture Sync for WordPress and Buddypress',
                'addonDescription'  => 'Update your WordPress and Buddypress profile picture with thumbnail photos stored in your LDAP directory.',
                'addonPrice' => '119',
                'addonLicense' => 'ContactUs',

            ],
            "ULTIMATE_MEMBER_LOGIN_INTEGRATION" =>      [
                'addonName'  => 'Ultimate Member Login Integration',
                'addonDescription'  => 'Login to Ultimate Member with LDAP Credentials.',
                'addonPrice' => '99',
                'addonLicense' => 'ContactUs',
            ],
            "PAGE_POST_RESTRICTION" =>      [
                'addonName'  => 'Page/Post Restriction Add-on',
                'addonDescription'  => 'Allows you to control access to your site\'s content (pages/posts) based on LDAP groups/WordPress roles.',
                'addonPrice' => '149',
                'addonLicense' => 'ContactUs',

            ],
            "LDAP_SEARCH_WIDGET" =>      [
                'addonName'  => 'Search Staff from LDAP Directory',
                'addonDescription'  => 'You can search/display your directory users on your website using search widget and shortcode.',
                'addonPrice' => '129',
                'addonLicense' => 'wp_ldap_search_widget_plan',

            ],
            "USER_META" =>      [
                'addonName'  => 'Third Party Plugin User Profile Integration',
                'addonDescription'  => 'Update profile information of any third-party plugin with information from LDAP Directory.',
                'addonPrice' => '149',
                'addonLicense' => 'ContactUs',

            ],
            "GRAVITY_FORMS_INTEGRATION" =>      [
                'addonName'  => 'Gravity Forms Integration',
                'addonDescription'  => 'Populate Gravity Form fields with information from LDAP. You can integrate with unlimited forms.',
                'addonPrice' => '129',
                'addonLicense' => 'ContactUs',

            ],
            "BUDDYPRESS_GROUP_SYNC" =>      [
                'addonName'  => 'Sync Buddypress Groups',
                'addonDescription'  => 'Assign BuddyPress groups to users based on group membership in LDAP.',
                'addonPrice' => '129',
                'addonLicense' => 'ContactUs',

            ],
            "MEMBERPRESS_INTEGRATION" =>      [
                'addonName'  => 'Memberpress Plugin Integration',
                'addonDescription'  => 'Login to Memberpress protected content with LDAP Credentials.',
                'addonPrice' => '99',
                'addonLicense' => 'ContactUs',
            ],
            "EMEMBER_INTEGRATION" =>      [
                'addonName'  => 'eMember Plugin Integration',
                'addonDescription'  => 'Login to eMember profiles with LDAP Credentials.',
                'addonPrice' => '99',
                'addonLicense' => 'ContactUs',

            ],

        )));


    }
    public static function showAddonsContent(){
        $displayMessage = "";
        $messages = unserialize(MO_LDAP_ADDONS_CONTENT);
        echo '<div id="ldap_addon_container" class="mo_ldap_wrapper">';
        $queryBody = "Hi! I am interested in the {{addonName}} addon, could you please tell me more about this addon?";
        foreach ($messages as $messageKey)
        {
            echo'
                
                    <div class="cd-pricing-wrapper-addons">
                        <div data-type="singlesite" class="is-visible ldap-addon-box">
                        <div class="individual-container-addons" style="height:100%;" >
                            <header class="cd-pricing-header">
                               <div style="height:35px"> <h2>'.$messageKey['addonName'].'</h2></div><br><br>
                                <hr >
                                <div style="height: 100px;display: grid;align-items: center;"><h3  class="subtitle" style="color:black;padding-left:unset;vertical-align: middle;text-align: center;letter-spacing: 1px">'.$messageKey['addonDescription'].'</h3></div><br>
                                <div class="cd-priceAddon">
                                    <span class="cd-currency">$</span>
                                    <!-- <span class="cd-value">149*</span></span> -->
                                    <div style="display:inline"><span class="cd-value" id="addon2Price" >'.$messageKey['addonPrice'].' </span><p style="display:inline;font-size:20px" id="addon2Text"> / instance</p></span>
                                 </div>

                                </div>
                            </header> <!-- .cd-pricing-header -->
                            <footer>
                                <a id="" href="#" style="text-align: center;display:inherit" class="cd-select" ';
                                

                                if($messageKey['addonLicense'] !== "ContactUs") {
                                    $linkText = "Upgrade Now";
                                    $onclick = 'onclick="upgradeform(\''.$messageKey['addonLicense'].'\')"';
                                }
                                else{
                                    $linkText = "Contact Us";
                                    $onclick = 'onclick="openSupportForm(\''.$messageKey['addonName'].'\')"';
                                }


            echo $onclick. ' >' .$linkText.' </a>
                             </footer>
                        </div>
                      
                       
                    </div> </div>
                ';

        }
        echo '</div><br>';
        return $displayMessage;
    }

}