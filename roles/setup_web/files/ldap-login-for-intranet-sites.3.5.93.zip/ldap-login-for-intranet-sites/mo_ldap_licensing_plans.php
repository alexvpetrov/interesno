<?php
include_once dirname( __FILE__ ) . '/add-on-framework.php';
include_once dirname( __FILE__ ) . '/ldap_pricing.php';

function mo_ldap_show_licensing_page(){
    
    echo '<style>.update-nag, .updated, .error, .is-dismissible, .notice, .notice-error { display: none; }</style>';
    ?>
    <style>
        *, *::after, *::before {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }

        html {
            font-size: 62.5%;
        }

        html * {
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .pricing-container {
            font-size: 1.6rem;
            font-family: "Open Sans", sans-serif;
            color: #fff;
        }

        /* --------------------------------

        Main Components

        -------------------------------- */
        .cd-header{
            margin-top:100px;
        }
        .cd-header>h1{
            text-align: center;
            color: #FFFFFF;
            font-size: 3.2rem;
        }

        .cd-pricing-container {
            /* width: 90%;
            max-width: 1160px;
            margin: 4em auto; */
            width: 100%;
            max-width: 1360px;
            /* margin: 4em auto; */
            margin-top: 0em;
            margin-right: auto;
            margin-left: auto;
        }
        .miniorange_container{
            padding-right: 10px;    

        }
        /* @media only screen and (min-width: 768px) {
            .cd-pricing-container {
                margin: auto;
            }
            .cd-pricing-container.cd-full-width {
                width: 100%;
                max-width: none;
            }
        } */

        .cd-pricing-switcher {
            text-align: center;
            margin-top: -3em;
        }
        .cd-pricing-switcher .fieldset {
            display: inline-block;
            position: relative;
            border-radius: 50em;
            border: 1px solid #e97d68;
        }
        .cd-pricing-switcher input[type="radio"] {
            position: absolute;
            opacity: 0;
        }
        .cd-pricing-switcher label {
            position: relative;
            z-index: 1;
            display: inline-block;
            float: left;
            width: 160px;
            height: 40px;
            line-height: 40px;
            cursor: pointer;
            font-size: 1.4rem;
            color: #FFFFFF;
            font-size:18px;
        }
        .cd-pricing-switcher .cd-switch {
            /* floating background */
            position: absolute;
            top: 2px;
            left: 2px;
            height: 40px;
            width: 160px;
            /* background-color: black; */
            background-color:#e97d68;
            border-radius: 50em;
            -webkit-transition: -webkit-transform 0.5s;
            -moz-transition: -moz-transform 0.5s;
            transition: transform 0.5s;
        }
        .cd-pricing-switcher input[type="radio"]:checked + label + .cd-switch,
        .cd-pricing-switcher input[type="radio"]:checked + label:nth-of-type(n) + .cd-switch {
            /* use label:nth-of-type(n) to fix a bug on safari with multiple adjacent-sibling selectors*/
            -webkit-transform: translateX(155px);
            -moz-transform: translateX(155px);
            -ms-transform: translateX(155px);
            -o-transform: translateX(155px);
            transform: translateX(155px);
        }

        .no-js .cd-pricing-switcher {
            display: none;
        }

        .cd-pricing-list {
            margin: 2em 0 0;
        }
        .cd-pricing-list > li {
            position: relative;
          
        }
        @media only screen and (min-width: 768px) {
            .cd-pricing-list {
                margin: 3em;
            }
            .cd-pricing-list:after {
                content: "";
                display: table;
                clear: both;
            }
            .cd-pricing-list > li {
                width: 35.3333333333%;
                float: left;
            }
            .cd-has-margins .cd-pricing-list > li {
                width: 32%;
                float: left;
                margin-right: 1%;
            }
            .cd-pricing-list-addon>li
            {
                width: 32.33%;
                float: left;
                margin-right: 1%;
            }


            .cd-addons-list>li{

                width: 19%;
                float: left;
                margin-right: 1%;
            }
            .cd-has-margins .cd-pricing-list > li:last-of-type {
                margin-right: 0;
            }
        }

        .cd-pricing-wrapper {
            /* this is the item that rotates */
            overflow: show;
            position: relative;
            width:
        }



        .touch .cd-pricing-wrapper {
            /* fix a bug on IOS8 - rotating elements dissapear*/
            -webkit-perspective: 2000px;
            -moz-perspective: 2000px;
            perspective: 2000px;
        }
        .cd-pricing-wrapper.is-switched .is-visible {
            /* totate the tables - anticlockwise rotation */
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation: cd-rotate 0.5s;
            -moz-animation: cd-rotate 0.5s;
            animation: cd-rotate 0.5s;
        }
        .cd-pricing-wrapper.is-switched .is-hidden {
            /* totate the tables - anticlockwise rotation */
            -webkit-transform: rotateY(0);
            -moz-transform: rotateY(0);
            -ms-transform: rotateY(0);
            -o-transform: rotateY(0);
            transform: rotateY(0);
            -webkit-animation: cd-rotate-inverse 0.5s;
            -moz-animation: cd-rotate-inverse 0.5s;
            animation: cd-rotate-inverse 0.5s;
            opacity: 0;
        }
        .cd-pricing-wrapper.is-switched .is-selected {
            opacity: 1;
        }
        .cd-pricing-wrapper.is-switched.reverse-animation .is-visible {
            /* invert rotation direction - clockwise rotation */
            -webkit-transform: rotateY(-180deg);
            -moz-transform: rotateY(-180deg);
            -ms-transform: rotateY(-180deg);
            -o-transform: rotateY(-180deg);
            transform: rotateY(-180deg);
            -webkit-animation: cd-rotate-back 0.5s;
            -moz-animation: cd-rotate-back 0.5s;
            animation: cd-rotate-back 0.5s;
        }
        .cd-pricing-wrapper.is-switched.reverse-animation .is-hidden {
            /* invert rotation direction - clockwise rotation */
            -webkit-transform: rotateY(0);
            -moz-transform: rotateY(0);
            -ms-transform: rotateY(0);
            -o-transform: rotateY(0);
            transform: rotateY(0);
            -webkit-animation: cd-rotate-inverse-back 0.5s;
            -moz-animation: cd-rotate-inverse-back 0.5s;
            animation: cd-rotate-inverse-back 0.5s;
            opacity: 0;
        }
        .cd-pricing-wrapper.is-switched.reverse-animation .is-selected {
            opacity: 1;
        }
        .cd-pricing-wrapper > li {
            background-color: #FFFFFF;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            /* Firefox bug - 3D CSS transform, jagged edges */
            outline: 1px solid transparent;
        }
        .cd-pricing-wrapper > li::after {
            /* subtle gradient layer on the right - to indicate it's possible to scroll */
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            height: 100%;
            width: 50px;
            pointer-events: none;
            background: -webkit-linear-gradient( right , #FFFFFF, rgba(255, 255, 255, 0));
            background: linear-gradient(to left, #FFFFFF, rgba(255, 255, 255, 0));
        }
        .cd-pricing-wrapper > li.is-ended::after {
            /* class added in jQuery - remove the gradient layer when it's no longer possible to scroll */
            display: none;
        }
        .cd-pricing-wrapper .is-visible {
            /* the front item, visible by default */
            position: relative;
            background-color: #f2f5f8;
        }
        .cd-pricing-wrapper .is-hidden {
            /* the hidden items, right behind the front one */
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            z-index: 1;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }
        .cd-pricing-wrapper .is-selected {
            /* the next item that will be visible */
            z-index: 3 !important;
        }
        @media only screen and (min-width: 768px) {
            .cd-pricing-wrapper > li::before {
                /* separator between pricing tables - visible when number of tables > 3 */
                content: '';
                position: absolute;
                z-index: 6;
                left: -1px;
                top: 50%;
                bottom: auto;
                -webkit-transform: translateY(-50%);
                -moz-transform: translateY(-50%);
                -ms-transform: translateY(-50%);
                -o-transform: translateY(-50%);
                transform: translateY(-50%);
                height: 50%;
                width: 1px;
                background-color: #b1d6e8;
            }
            .cd-pricing-wrapper > li::after {
                /* hide gradient layer */
                display: none;
            }
            .cd-popular .cd-pricing-wrapper > li {
                box-shadow: inset 0 0 0 3px #e97d68;
            }
            .cd-has-margins .cd-pricing-wrapper > li, .cd-has-margins .cd-popular .cd-pricing-wrapper > li  {
                box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
            }
            .cd-secondary-theme .cd-pricing-wrapper  > li {
                background: #3aa0d1;
                background: -webkit-linear-gradient( bottom , #3aa0d1, #3ad2d1);
                background: linear-gradient(to top, #3aa0d1, #3ad2d1);
            }
            .cd-secondary-theme .cd-popular .cd-pricing-wrapper > li  {
                background: #e97d68;
                background: -webkit-linear-gradient( bottom , #e97d68, #e99b68);
                background: linear-gradient(to top, #e97d68, #e99b68);
                box-shadow: none;
            }
            .cd-pricing-wrapperTitle > li{
                background:#c1d2d5;
                /* background: -webkit-linear-gradient( bottom , #e97d68, #e97d68);
                background: linear-gradient(to top, #e97d68, #e97d68);
                box-shadow: none; */

            }
            :nth-of-type(1) > .cd-pricing-wrapper > li::before {
                /* hide table separator for the first table */
                display: none;
            }
            .cd-has-margins .cd-pricing-wrapper > li {
                border-radius: 4px 4px 6px 6px;
            }
            .cd-has-margins .cd-pricing-wrapper > li::before {
                display: none;
            }
        }
        @media only screen and (min-width: 1500px) {
            .cd-full-width .cd-pricing-wrapper > li {
                padding: 2.5em 0;
            }
        }

        .no-js .cd-pricing-wrapper .is-hidden .cd-pricing-wrapperTitle{
            position: relative;
            -webkit-transform: rotateY(0);
            -moz-transform: rotateY(0);
            -ms-transform: rotateY(0);
            -o-transform: rotateY(0);
            transform: rotateY(0);
            margin-top: 1em;
        }

        @media only screen and (min-width: 768px) {
            .cd-popular .cd-pricing-wrapper > li::before {
                /* hide table separator for .cd-popular table */
                display: none;
            }

            .cd-popular + li .cd-pricing-wrapper > li::before {
                /* hide table separator for tables following .cd-popular table */
                display: none;
            }
        }


        /* remove */
        .cd-pricing-wrapper-addons {
            /* this is the item that rotates */
            overflow: show;
            position: relative;
        }



        .touch .cd-pricing-wrapper-addons {
            /* fix a bug on IOS8 - rotating elements dissapear*/
            -webkit-perspective: 2000px;
            -moz-perspective: 2000px;
            perspective: 2000px;
        }
        .cd-pricing-wrapper-addons.is-switched .is-visible {
            /* totate the tables - anticlockwise rotation */
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
            -webkit-animation: cd-rotate 0.5s;
            -moz-animation: cd-rotate 0.5s;
            animation: cd-rotate 0.5s;
        }
        .cd-pricing-wrapper-addons.is-switched .is-hidden {
            /* totate the tables - anticlockwise rotation */
            -webkit-transform: rotateY(0);
            -moz-transform: rotateY(0);
            -ms-transform: rotateY(0);
            -o-transform: rotateY(0);
            transform: rotateY(0);
            -webkit-animation: cd-rotate-inverse 0.5s;
            -moz-animation: cd-rotate-inverse 0.5s;
            animation: cd-rotate-inverse 0.5s;
            opacity: 0;
        }
        .cd-pricing-wrapper-addons.is-switched .is-selected {
            opacity: 1;
        }
        .cd-pricing-wrapper-addons.is-switched.reverse-animation .is-visible {
            /* invert rotation direction - clockwise rotation */
            -webkit-transform: rotateY(-180deg);
            -moz-transform: rotateY(-180deg);
            -ms-transform: rotateY(-180deg);
            -o-transform: rotateY(-180deg);
            transform: rotateY(-180deg);
            -webkit-animation: cd-rotate-back 0.5s;
            -moz-animation: cd-rotate-back 0.5s;
            animation: cd-rotate-back 0.5s;
        }
        .cd-pricing-wrapper-addons.is-switched.reverse-animation .is-hidden {
            /* invert rotation direction - clockwise rotation */
            -webkit-transform: rotateY(0);
            -moz-transform: rotateY(0);
            -ms-transform: rotateY(0);
            -o-transform: rotateY(0);
            transform: rotateY(0);
            -webkit-animation: cd-rotate-inverse-back 0.5s;
            -moz-animation: cd-rotate-inverse-back 0.5s;
            animation: cd-rotate-inverse-back 0.5s;
            opacity: 0;
        }
        .cd-pricing-wrapper-addons.is-switched.reverse-animation .is-selected {
            opacity: 1;
        }
        .cd-pricing-wrapper-addons > li {
            background-color: #FFFFFF;
            -webkit-backface-visibility: hidden;
            backface-visibility: hidden;
            /* Firefox bug - 3D CSS transform, jagged edges */
            outline: 1px solid transparent;
        }
        .cd-pricing-wrapper-addons > li::after {
            /* subtle gradient layer on the right - to indicate it's possible to scroll */
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            height: 100%;
            width: 50px;
            pointer-events: none;
            background: -webkit-linear-gradient( right , #FFFFFF, rgba(255, 255, 255, 0));
            background: linear-gradient(to left, #FFFFFF, rgba(255, 255, 255, 0));
        }
        .cd-pricing-wrapper-addons > li.is-ended::after {
            /* class added in jQuery - remove the gradient layer when it's no longer possible to scroll */
            display: none;
        }
        .cd-pricing-wrapper-addons .is-visible {
            /* the front item, visible by default */
            position: relative;
            background-color: #f2f5f8;
        }
        .cd-pricing-wrapper-addons .is-hidden {
            /* the hidden items, right behind the front one */
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            z-index: 1;
            -webkit-transform: rotateY(180deg);
            -moz-transform: rotateY(180deg);
            -ms-transform: rotateY(180deg);
            -o-transform: rotateY(180deg);
            transform: rotateY(180deg);
        }
        .cd-pricing-wrapper-addons .is-selected {
            /* the next item that will be visible */
            z-index: 3 !important;
        }
        @media only screen and (min-width: 768px) {
            .cd-pricing-wrapper-addons > li::before {
                /* separator between pricing tables - visible when number of tables > 3 */
                content: '';
                position: absolute;
                z-index: 6;
                left: -1px;
                top: 50%;
                bottom: auto;
                -webkit-transform: translateY(-50%);
                -moz-transform: translateY(-50%);
                -ms-transform: translateY(-50%);
                -o-transform: translateY(-50%);
                transform: translateY(-50%);
                height: 50%;
                width: 1px;
                background-color: #b1d6e8;
            }
            .cd-pricing-wrapper-addons > li::after {
                /* hide gradient layer */
                display: none;
            }
            .cd-popular .cd-pricing-wrapper-addons > li {
                box-shadow: inset 0 0 0 3px #e97d68;
            }
            .cd-has-margins .cd-pricing-wrapper-addons > li, .cd-has-margins .cd-popular .cd-pricing-wrapper-addons > li  {
                box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
            }
            .cd-secondary-theme .cd-pricing-wrapper-addons  > li {
                background: #3aa0d1;
                background: -webkit-linear-gradient( bottom , #3aa0d1, #3ad2d1);
                background: linear-gradient(to top, #3aa0d1, #3ad2d1);
            }
            .cd-secondary-theme .cd-popular .cd-pricing-wrapper-addons > li  {
                background: #e97d68;
                background: -webkit-linear-gradient( bottom , #e97d68, #e99b68);
                background: linear-gradient(to top, #e97d68, #e99b68);
                box-shadow: none;
            }
            .cd-pricing-wrapper-addonsTitle > li{
                background:#c1d2d5;
                /* background: -webkit-linear-gradient( bottom , #e97d68, #e97d68);
                background: linear-gradient(to top, #e97d68, #e97d68);
                box-shadow: none; */

            }
            :nth-of-type(1) > .cd-pricing-wrapper-addons > li::before {
                /* hide table separator for the first table */
                display: none;
            }
            .cd-has-margins .cd-pricing-wrapper-addons > li {
                border-radius: 4px 4px 6px 6px;
            }
            .cd-has-margins .cd-pricing-wrapper-addons > li::before {
                display: none;
            }
        }
        @media only screen and (min-width: 1500px) {
            .cd-full-width .cd-pricing-wrapper-addons > li {
                padding: 2.5em 0;
            }
        }

        .no-js .cd-pricing-wrapper-addons .is-hidden .cd-pricing-wrapper-addonsTitle{
            position: relative;
            -webkit-transform: rotateY(0);
            -moz-transform: rotateY(0);
            -ms-transform: rotateY(0);
            -o-transform: rotateY(0);
            transform: rotateY(0);
            margin-top: 1em;
        }

        @media only screen and (min-width: 768px) {
            .cd-popular .cd-pricing-wrapper-addons > li::before {
                /* hide table separator for .cd-popular table */
                display: none;
            }

            .cd-popular + li .cd-pricing-wrapper-addons > li::before {
                /* hide table separator for tables following .cd-popular table */
                display: none;
            }
        }


        /* remove */




        .cd-pricing-header {
            position: relative;

            height: 80px;
            padding: 1em;
            pointer-events: none;
            background-color: #3aa0d1;
            color: #FFFFFF;
        }
        .cd-pricing-header h2 {
            margin-bottom: 3px;
            font-weight: 500;
            text-transform: uppercase;
        }
        .cd-popular .cd-pricing-header {
            background-color: #e97d68;
        }
        @media only screen and (min-width: 768px) {
            .cd-pricing-header {
                height: auto;
                padding: 1.9em 0.9em 1.6em;
                pointer-events: auto;
                text-align: center;
                color: #2f6062;
                background-color: transparent;
            }
            .cd-popular .cd-pricing-header {
                color: #e97d68;
                background-color: transparent;
            }
            .cd-secondary-theme .cd-pricing-header {
                color: #FFFFFF;
            }
            .cd-pricing-header h2 {
                font-size: 1.8rem;
                letter-spacing: 2px;
                font-weight:500;
            }
        }

        .cd-currency, .cd-value {
            font-size: 4rem;
            font-weight: 300;
        }

        .cd-duration {
            font-weight: 800;
            font-size: 1.3rem;
            color: #8dc8e4;
            text-transform: uppercase;
        }
        .user-label {
            font-weight: 700;
            font-size: 1.3rem;
            color: #8dc8e4;
            text-transform: uppercase;
        }
        .cd-popular .cd-duration {
            color: #f3b6ab;
        }
        .cd-duration::before {
            content: '/';
            margin-right: 2px;
        }

        @media only screen and (min-width: 768px) {
            .cd-value {
                font-size: 4rem;
                font-weight: 300;
            }

            .cd-contact {
                font-size: 3rem;

            }

            .cd-currency, .cd-duration {
                color: rgba(23, 61, 80, 0.4);
            }
            .cd-popular .cd-currency, .cd-popular .cd-duration {
                color: #e97d68;
            }
            .cd-secondary-theme .cd-currency, .cd-secondary-theme .cd-duration {
                color: #2e80a7;
            }
            .cd-secondary-theme .cd-popular .cd-currency, .cd-secondary-theme .cd-popular .cd-duration {
                color: #ba6453;
            }

            .cd-currency {
                display: inline-block;
                vertical-align: top;
                font-size: 2rem;
                font-weight: 700;
            }

            .cd-duration {
                font-size: 1.4rem;
            }
        }
        .cd-pricing-body {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        .is-switched .cd-pricing-body {
            /* fix a bug on Chrome Android */
            overflow: hidden;
        }
        @media only screen and (min-width: 768px) {
            .cd-pricing-body {
                overflow-x: visible;
            }
        }

        .cd-pricing-features {
            width: 600px;
        }
        .cd-pricing-features:after {
            content: "";
            display: table;
            clear: both;
        }
        .cd-pricing-features li {
            width: 100px;
            float: left;
            padding: 1.6em 1em;
            font-size: 1.4rem;
            text-align: center;
            white-space: initial;

            line-height:1.4em;

            text-overflow: ellipsis;
            color: black;
            overflow-wrap: break-word;
            margin: 0 !important;

        }
        .cd-pricing-features em {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: black;
        }
        @media only screen and (min-width: 768px) {
            .cd-pricing-features {
                width: auto;
                word-wrap: break-word;
            }
            .cd-pricing-features li {
                float: none;
                width: auto;
                padding: 1em;
                word-wrap: break-word;
            }
            .cd-popular .cd-pricing-features li {
                margin: 0 3px;
            }
            .cd-pricing-features li:nth-of-type(2n+1) {
                background-color: rgba(23, 61, 80, 0.06);
            }
            .cd-pricing-features em {
                display: inline-block;
                margin-bottom: 0;
                word-wrap: break-word;
            }
            .cd-has-margins .cd-popular .cd-pricing-features li, .cd-secondary-theme .cd-popular .cd-pricing-features li {
                margin: 0;
            }
            .cd-secondary-theme .cd-pricing-features li {
                color: #FFFFFF;
            }
            .cd-secondary-theme .cd-pricing-features li:nth-of-type(2n+1) {
                background-color: transparent;
            }
        }

        .cd-pricing-footer {
            position: absolute;
            z-index: 1;
            top: 0;
            left: 0;
            /* on mobile it covers the .cd-pricing-header */
            height: 120px;
            width: 100%;
        }

        .cd-pricing-footer-addon{

            position: absolute;
            z-index: 1;
            top: 0;
            left: 0;
            /* on mobile it covers the .cd-pricing-header */
            /* height: 40px; */
            height: 160px;
            width: 100%;
        }

        .cd-pricing-footer-addon::after{

            content: '';
            position: absolute;
            right: 1em;
            top: 50%;
            bottom: auto;
            -webkit-transform: translateY(-50%);
            -moz-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            -o-transform: translateY(-50%);
            transform: translateY(-50%);
            height: 80px; 
            width: 20px;
}


        .cd-pricing-footer::after {
            /* right arrow visible on mobile */
            content: '';
            position: absolute;
            right: 1em;
            top: 50%;
            bottom: auto;
            -webkit-transform: translateY(-50%);
            -moz-transform: translateY(-50%);
            -ms-transform: translateY(-50%);
            -o-transform: translateY(-50%);
            transform: translateY(-50%);
            height: 20px;
            width: 20px;
            
        }
        @media only screen and (min-width: 768px) {
            .cd-pricing-footer {
                position: relative;
                /* height: 135px; */
                
               
                padding-right: 0px;
                padding-bottom: 6em;

                text-align: center;
            }
            .cd-pricing-footer-addon {
                /* position: relative; */
                /* height: 135px; */
                
               
                padding-right: 0px;
              
                padding-left: 0px;
                height:40px;
                text-align: center;
            }
            .cd-pricing-footer::after {
                /* hide arrow */
                display: none;
            }
            .cd-has-margins .cd-pricing-footer {
                padding-bottom: 0;
            }
        }

        .cd-select {
            position: relative;
            z-index: 1;
            display: block;
            height: 100%;
            /* hide button text on mobile */
            overflow: hidden;
            text-indent: 100%;
            white-space: nowrap;
            color: transparent;
        }
        @media only screen and (min-width: 768px) {
            .cd-select {
                position: static;
                display: inline-block;
                height: auto;
                padding: 1.3em 3em;
                color: #FFFFFF;
                border-radius: 2px;
                background-color: #0c1f28;
                font-size: 1.4rem;
                text-indent: 0;
                text-transform: uppercase;
                letter-spacing: 2px;
            }
            .no-touch .cd-select:hover {
                background-color: #112e3c;
            }
            .cd-popular .cd-select {
                background-color: #e97d68;
            }
            .no-touch .cd-popular .cd-select:hover {
                background-color: #ec907e;
            }
            .cd-secondary-theme .cd-popular .cd-select {
                background-color: #0c1f28;
            }
            .no-touch .cd-secondary-theme .cd-popular .cd-select:hover {
                background-color: #112e3c;
            }
            .cd-has-margins .cd-select {
                display: block;
                padding: 1.7em 0;
                border-radius: 0 0 4px 4px;
            }
            .cd-select-instance
            {
                padding: 1.7em 0;
                
                border-radius: 0 0 4px 4px;

            }
            .PricingCard-toggle>button {
                
                cursor: pointer;
                width: 100%;
                /* max-width: 1360px; */
                max-width: 393px;
                margin: 4em auto;
                color: #007dc1;
                font-size: 24px;
                font-weight: 600;
                line-height: 16px;
                padding: 16px 0;
                -ms-flex-align: center;
                align-items: center;
                background-color: transparent;
                border-radius: 0;
                border: none;
                box-shadow: none;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-pack: center;
                justify-content: center;
                letter-spacing: 1.5px;
                margin: 0 auto;
                text-align: center;
                 
            }
            .PricingCard-toggle-addon>button {
                
                cursor: pointer;
                width: 20%;
                max-width: 1360px;
                margin: 4em auto;
                color: #007dc1;
                font-size: 24px;
                font-weight: 600;
                line-height: 16px;
                padding: 16px 0;
                -ms-flex-align: center;
                align-items: center;
                background-color: transparent;
                border-radius: 0;
                border: none;
                box-shadow: none;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-pack: center;
                justify-content: center;
                letter-spacing: 1.5px;
                margin: 0 auto;
                text-align: center;
                 padding-top: 22px;;

                padding-bottom: 35px;
                 
            }

            button:focus {
            outline: 0px;
            }
.tick-mark {
    position: relative;
    display: inline-block;
    width: 30px;
    height: 25px;
    margin-left: 150px;
    margin-right: 150px;
}

.tick-mark::before {
    position: absolute;
  
    left: 0;
    top: 50%;
    height: 50%;
    width: 3px;
    background-color: #336699;
    content: "";
    transform: translateX(10px) rotate(-45deg);
    transform-origin: left bottom;
}

.tick-mark::after {
    position: absolute;
    
    left: 0;
    bottom: 0;
    height: 3px;
    width: 100%;
    background-color: #336699;
    content: "";
    transform: translateX(10px) rotate(-45deg);
    transform-origin: left bottom;
}


.PricingCard-detail, .PricingCard-label {

    font-size: 16px;
    font-weight: 400;
    line-height: 24px;
}
section#content {
 
 
 
  margin-top: 80px;
  max-width: 1360px;
    width: 100%;

            margin: 4em auto;
}


body, dl, dt, dd, ul, ol,  h1, h2, h3, h4, h5, h6, pre, form, fieldset, input, textarea, p, blockquote, th, td {
  margin: 0;
  padding:0;
}
/* li{
    margin: 0;
  padding: 0;
} */
.cd-price{
    margin-top:115px;
}

.main.pad {
    padding: 35px 40px;
}

.main {
  margin: 0 auto;
  position: relative;
}


.main-block {
    width: 100%;
    /* max-width: 1170px; */
    max-width:1360px;
    margin: 4em auto;
  margin: 0 auto;
  /* background: #ebf7f3; */
  overflow: hidden;
  border-radius: 3px;
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  margin-top: 20px;
}

section#content {
  position: relative;
  z-index: 10;
  
  margin-top: 0px;
}

.main-block h2 {
  font-size: 32px;
  font-family: 'Open Sans', sans-serif;
  font-weight: bold;
  padding-bottom: 40px;
  color: black;
  text-align: center;
  padding-bottom:4px;
}
th.firstCol
{

    width:10px;
}
/* TABLE */

/* AUTHOR LINK */



.FeatureList
{
    width: 100%;
            max-width: 1320px;
            margin: 4em auto;
            

}

.FeatureListThirdAddon
{
    width: 100%;
            max-width: 1360px;
            margin: 4em auto;

}
.selected {
    z-index: 0px;
    height: 20px;
    padding: 10 20px;
    font-size: 12px;
    line-height: 10px;
    text-align: center;
    color: #fff;
    font-weight: bold;
    box-shadow: 0px 2px 5px #888888;
    background: #2f6062;
    border-top: 5px solid #2f6062;
    border-bottom: 5px solid #2f6062;
  
    background: #palegoldenrod;
    transform: rotate(38deg);
    position: absolute;
    right: -4px;
    top: 17px;
    width: 70px;
}
.selectedSupport {
    z-index: 10px;
   
    padding: 10 20px;
    font-size: 10px;
    line-height: 7px;
    text-align: center;
    color: #fff;
    font-weight: bold;
    box-shadow: 0px 2px 5px #888888;
    background: #2f6062;
    border-top: 5px solid #2f6062;
    border-bottom: 5px solid #2f6062;
  
    background: #palegoldenrod;
    transform: rotate(42deg);
    position: absolute;
    right: -90px;
    top: 8px;
    width: 56px;
   
}



.FeatureList, .FeatureListThirdAddon{

  border:0px;
}

.responsive-table {
  width: 100%;
  margin-bottom: 2em;
  max-width: 1360px;
  font-size: 1em;  
    margin-right: 13px;
}
@media (min-width: 48em) {
  .responsive-table {
    font-size: .9em;
  }
}
@media (min-width: 68em) {
  .responsive-table {
    font-size: 1em;
    width: 0px;
    margin: 0 auto;
    margin-bottom: 2em;
  }

    .table_small{
          width: 400px;
    }

}
.responsive-table thead {
  position: absolute;
  clip: rect(1px 1px 1px 1px);
  /* IE6, IE7 */
  clip: rect(1px, 1px, 1px, 1px);
  padding: 0;
  border: 0;
  height: 1px;
  width: 1px;
  overflow: hidden;
}
@media (min-width: 48em) {
  .responsive-table thead {
      
    position: relative;
    clip: auto;
    height: auto;
    width: auto;
    overflow: auto;
  }
}
.responsive-table thead th {
   
background-color: #e97d68;
border: 1px solid #000000;
font-weight: normal;
font-weight: bold;
text-align: center;
font-size: 18px;
color: white;

}


.responsive-table tr,
.responsive-table th,
.responsive-table td {
display: block;
padding: 0;
text-align: left;
/* text-align: center; */
white-space: normal;
}
@media (min-width: 48em) {
  .responsive-table tr {
    display: table-row;
  }
}
.responsive-table th,
.responsive-table td {
  padding: .5em;
  vertical-align: middle;
    font-size: 15px;
}

  .responsive-table td{
    border-bottom: 1px solid #000000;
    border-right: 1px solid black;
  }

  .responsive-table tbody td {
    border: 1px solid #000000;
}

}



@media (min-width: 48em) {
  .responsive-table th,
  .responsive-table td {
    display: table-cell;
    padding: .5em;
  }
}
@media (min-width: 62em) {
  .responsive-table th,
  .responsive-table td {
    /* padding: .75em .5em; */
  }
}
@media (min-width: 75em) {
  .responsive-table th,
  .responsive-table td {
    /* padding: .75em; */
  }
}
.responsive-table caption {
  margin-bottom: 1em;
  font-size: 1em;
  font-weight: bold;
  text-align: center;
}
@media (min-width: 48em) {
  .responsive-table caption {
    font-size: 1.5em;
  }
}
.responsive-table tfoot {
  font-size: .8em;
  font-style: italic;
}
@media (min-width: 62em) {
  .responsive-table tfoot {
    font-size: .9em;
  }
}
@media (min-width: 48em) {
  .responsive-table tbody {
    display: table-row-group;
  }
}
.responsive-table tbody tr {
  margin-bottom: 3em;
/* border: 2px solid #FFFFFF; */
}
@media (min-width: 48em) {
  .responsive-table tbody tr {
    display: table-row;
    border-width: 1px;
  }
}
.responsive-table tbody tr:last-of-type {
  margin-bottom: 0;
}
@media (min-width: 48em) {
  .responsive-table tbody tr:nth-of-type(even) {
    background-color: rgba(94, 93, 82, 0.1);
  }
}
.responsive-table tbody th[scope="row"] {
  /* background-color: #1d96b2; */
color: white;
border: 1px solid #000000;
font-weight: bold;
/* background: white; */
}
@media (min-width: 48em) {
  .responsive-table tbody th[scope="row"] {
    background-color: rgba(255, 255, 255, 1);
    color: #000000;
    text-align: center;
    
  }
}
.responsive-table tbody td {
  text-align: right;
background: rgba(255, 255, 255,1);
color: #000000;
font-weight: bold;
  font-size: 15px;
}



@media (min-width: 30em) {
  .responsive-table tbody td {
    border: 1px solid #000000;
  }
}
@media (min-width: 48em) {
  .responsive-table tbody td {
    text-align: center;
    border-bottom: 1px solid #000000;
    border-right: 1px solid black;
  }
}
.responsive-table tbody td[data-type=currency] {
  text-align: right;
}
.responsive-table tbody td[data-title]:before {
  content: attr(data-title);
  float: left;
  font-size: .8em;
  color: rgba(94, 93, 82, 0.75);
}
@media (min-width: 30em) {
  .responsive-table tbody td[data-title]:before {
    font-size: .9em;
  }
}
@media (min-width: 48em) {
  .responsive-table tbody td[data-title]:before {
    content: none;
  }
}

@media screen and (max-width: 600px){
.main-block {
  width: 100%;
}



.responsive-table tbody{
    font-family: 'Open Sans';
    font-size: 16px;
}
.down {
    color:blue;
  transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
}
i {
  border: solid blue;
  border-width: 0 3px 3px 0;
  display: inline-block;
  padding: 3px;
}
.subtitle h3{
   
    color: black;
    text-align:center;
    font-weight: 500;
    font-size:18px;
    position:absolute;
    line-height:normal;
    padding-left: 18%;
    padding-right: 16%;

}

.PricingCard-column{padding:0 32px;width:calc(50% - 170px)}

        }

@media only screen and (min-width: 768px){
.FeatureList, .FeatureListThirdAddon {
    border: 0px;
    max-width: 1360px;
}

}
        /* --------------------------------

        xkeyframes

        -------------------------------- */
        @-webkit-keyframes cd-rotate {
            0% {
                -webkit-transform: perspective(2000px) rotateY(0);
            }
            70% {
                /* this creates the bounce effect */
                -webkit-transform: perspective(2000px) rotateY(200deg);
            }
            100% {
                -webkit-transform: perspective(2000px) rotateY(180deg);
            }
        }
        @-moz-keyframes cd-rotate {
            0% {
                -moz-transform: perspective(2000px) rotateY(0);
            }
            70% {
                /* this creates the bounce effect */
                -moz-transform: perspective(2000px) rotateY(200deg);
            }
            100% {
                -moz-transform: perspective(2000px) rotateY(180deg);
            }
        }
        @keyframes cd-rotate {
            0% {
                -webkit-transform: perspective(2000px) rotateY(0);
                -moz-transform: perspective(2000px) rotateY(0);
                -ms-transform: perspective(2000px) rotateY(0);
                -o-transform: perspective(2000px) rotateY(0);
                transform: perspective(2000px) rotateY(0);
            }
            70% {
                /* this creates the bounce effect */
                -webkit-transform: perspective(2000px) rotateY(200deg);
                -moz-transform: perspective(2000px) rotateY(200deg);
                -ms-transform: perspective(2000px) rotateY(200deg);
                -o-transform: perspective(2000px) rotateY(200deg);
                transform: perspective(2000px) rotateY(200deg);
            }
            100% {
                -webkit-transform: perspective(2000px) rotateY(180deg);
                -moz-transform: perspective(2000px) rotateY(180deg);
                -ms-transform: perspective(2000px) rotateY(180deg);
                -o-transform: perspective(2000px) rotateY(180deg);
                transform: perspective(2000px) rotateY(180deg);
            }
        }
        @-webkit-keyframes cd-rotate-inverse {
            0% {
                -webkit-transform: perspective(2000px) rotateY(-180deg);
            }
            70% {
                /* this creates the bounce effect */
                -webkit-transform: perspective(2000px) rotateY(20deg);
            }
            100% {
                -webkit-transform: perspective(2000px) rotateY(0);
            }
        }
        @-moz-keyframes cd-rotate-inverse {
            0% {
                -moz-transform: perspective(2000px) rotateY(-180deg);
            }
            70% {
                /* this creates the bounce effect */
                -moz-transform: perspective(2000px) rotateY(20deg);
            }
            100% {
                -moz-transform: perspective(2000px) rotateY(0);
            }
        }
        @keyframes cd-rotate-inverse {
            0% {
                -webkit-transform: perspective(2000px) rotateY(-180deg);
                -moz-transform: perspective(2000px) rotateY(-180deg);
                -ms-transform: perspective(2000px) rotateY(-180deg);
                -o-transform: perspective(2000px) rotateY(-180deg);
                transform: perspective(2000px) rotateY(-180deg);
            }
            70% {
                /* this creates the bounce effect */
                -webkit-transform: perspective(2000px) rotateY(20deg);
                -moz-transform: perspective(2000px) rotateY(20deg);
                -ms-transform: perspective(2000px) rotateY(20deg);
                -o-transform: perspective(2000px) rotateY(20deg);
                transform: perspective(2000px) rotateY(20deg);
            }
            100% {
                -webkit-transform: perspective(2000px) rotateY(0);
                -moz-transform: perspective(2000px) rotateY(0);
                -ms-transform: perspective(2000px) rotateY(0);
                -o-transform: perspective(2000px) rotateY(0);
                transform: perspective(2000px) rotateY(0);
            }
        }
        @-webkit-keyframes cd-rotate-back {
            0% {
                -webkit-transform: perspective(2000px) rotateY(0);
            }
            70% {
                /* this creates the bounce effect */
                -webkit-transform: perspective(2000px) rotateY(-200deg);
            }
            100% {
                -webkit-transform: perspective(2000px) rotateY(-180deg);
            }
        }
        @-moz-keyframes cd-rotate-back {
            0% {
                -moz-transform: perspective(2000px) rotateY(0);
            }
            70% {
                /* this creates the bounce effect */
                -moz-transform: perspective(2000px) rotateY(-200deg);
            }
            100% {
                -moz-transform: perspective(2000px) rotateY(-180deg);
            }
        }
        @keyframes cd-rotate-back {
            0% {
                -webkit-transform: perspective(2000px) rotateY(0);
                -moz-transform: perspective(2000px) rotateY(0);
                -ms-transform: perspective(2000px) rotateY(0);
                -o-transform: perspective(2000px) rotateY(0);
                transform: perspective(2000px) rotateY(0);
            }
            70% {
                /* this creates the bounce effect */
                -webkit-transform: perspective(2000px) rotateY(-200deg);
                -moz-transform: perspective(2000px) rotateY(-200deg);
                -ms-transform: perspective(2000px) rotateY(-200deg);
                -o-transform: perspective(2000px) rotateY(-200deg);
                transform: perspective(2000px) rotateY(-200deg);
            }
            100% {
                -webkit-transform: perspective(2000px) rotateY(-180deg);
                -moz-transform: perspective(2000px) rotateY(-180deg);
                -ms-transform: perspective(2000px) rotateY(-180deg);
                -o-transform: perspective(2000px) rotateY(-180deg);
                transform: perspective(2000px) rotateY(-180deg);
            }
        }
        @-webkit-keyframes cd-rotate-inverse-back {
            0% {
                -webkit-transform: perspective(2000px) rotateY(180deg);
            }
            70% {
                /* this creates the bounce effect */
                -webkit-transform: perspective(2000px) rotateY(-20deg);
            }
            100% {
                -webkit-transform: perspective(2000px) rotateY(0);
            }
        }
        @-moz-keyframes cd-rotate-inverse-back {
            0% {
                -moz-transform: perspective(2000px) rotateY(180deg);
            }
            70% {
                /* this creates the bounce effect */
                -moz-transform: perspective(2000px) rotateY(-20deg);
            }
            100% {
                -moz-transform: perspective(2000px) rotateY(0);
            }
        }
        @keyframes cd-rotate-inverse-back {
            0% {
                -webkit-transform: perspective(2000px) rotateY(180deg);
                -moz-transform: perspective(2000px) rotateY(180deg);
                -ms-transform: perspective(2000px) rotateY(180deg);
                -o-transform: perspective(2000px) rotateY(180deg);
                transform: perspective(2000px) rotateY(180deg);
            }
            70% {
                /* this creates the bounce effect */
                -webkit-transform: perspective(2000px) rotateY(-20deg);
                -moz-transform: perspective(2000px) rotateY(-20deg);
                -ms-transform: perspective(2000px) rotateY(-20deg);
                -o-transform: perspective(2000px) rotateY(-20deg);
                transform: perspective(2000px) rotateY(-20deg);
            }
            100% {
                -webkit-transform: perspective(2000px) rotateY(0);
                -moz-transform: perspective(2000px) rotateY(0);
                -ms-transform: perspective(2000px) rotateY(0);
                -o-transform: perspective(2000px) rotateY(0);
                transform: perspective(2000px) rotateY(0);
            }
        }


        .tab-content {
            margin-left: 0%!important;
            margin-top: 0%!important;

        }
        .tab-content>.active {
            width: 100% !important;
        }

        .tab-pane,.cd-pricing-container,.cd-pricing-switcher ,.cd-row,.cd-row>div{

        }

        .center-pills { display: inline-block; }

        .nav-pills{
            border: 1px solid #fff;
            height:48px;
        }

        .nav-pills>li{
            width:250px;
        }

        .tab-font{
            vertical-align:text-bottom;
            font-size:20px;
        }

        .nav-pills>li+li {
            margin-left: 0px;
        }

        .nav-pills>li.active>a, .nav-pills>li.active>a:hover, .nav-pills>li.active>a:focus,.nav-pills>li.active>a:active{
            color: #1e3334;
            background-color:white;
            height:47px;
        }

        .nav-pills>li>a:hover {
            color:#fff;
            background: #E97D68;
            height:46px;
        }

        .nav-pills>li>a:focus{
            color:#fff;
            background:grey;
            height:47px;

        }

        .nav-pills>li.active{
            background-color: #fff;
        }

        .nav-pills>li>a {
            border-radius: 0px;
            height:47px;
            border-color:#E85700;
            font-weight: 500;
            color: #d3f3d3;
            text-transform:uppercase;
        }


        .ui-widget-content {
            border: 1px solid #bdc3c7;
            background: #e1e1e1;
            color: #222222;
            margin-top: 4px;
        }

        .ui-slider .ui-slider-handle {
            position: absolute !important;
            z-index: 2 !important;
            width: 3.2em !important;
            height: 2.2em !important;
            cursor: default !important;
            margin: 0 -20px auto !important;
            text-align: center !important;
            line-height: 30px !important;
            color: #FFFFFF !important;
            font-size: 15px !important;
        }




        .ui-state-default,
        .ui-widget-content .ui-state-default {
            background: #393a40 !important;
        }
        .ui-slider .ui-slider-handle {width:2em;left:-.6em;text-decoration:none;text-align:center;}
        .ui-slider-horizontal .ui-slider-handle {
            margin-left: -0.5em !important;
        }

        .ui-slider .ui-slider-handle {
            cursor: pointer;
        }

        .ui-slider a,
        .ui-slider a:focus {
            cursor: pointer;
            outline: none;
        }

        .price, .lead p {
            font-weight: 600;
            font-size: 32px;
            display: inline-block;
            line-height: 60px;
        }


        .price-slider {
            margin-top: 30px;
            margin-bottom: 30px;
        }

        .price-form {
            background: #ffffff;
            margin-bottom: 10px;
            padding: 20px;
            border: 1px solid #eeeeee;
            border-radius: 4px;
        }



        .help-text {
            display: block;
            margin-top: 32px;
            margin-bottom: 10px;
            color: #737373;
            position: absolute;
            font-weight: 200;
            text-align: right;
            width: 188px;
        }

        .price-form label {
            font-weight: 200;
            font-size: 21px;
        }

        .ui-slider-range-min {
            background: #2980b9;
        }

        .ui-slider-label-inner {
            border-top: 10px solid #393a40;
            display: block;
            left: 50%;
            position: absolute;
            top: 10%;
            z-index: 99;
        }

        .ui-slider-horizontal .ui-slider-handle {
            top: -.6em !important;
        }
        /***********************ADDED BY SHAILESH************************/

        .plan-tagline{
            margin:1px;
            font-size: 2rem;
            font-weight: 400;
        }

        .pricing-tooltip {
            position: relative;
            display: inline-block;
            /* color:black; */
        }

        .tooltip {
            display:none;
            background: black;
            font-size:12px;
            height:10px;
            width:80px;
            padding:10px;
            color:#fff;
            z-index: 99;
            bottom: 10px;
            border: 2px solid white;
            /* for IE */
            filter:alpha(opacity=80);
            /* CSS3 standard */
            opacity:0.8;
        }
        .pricing-tooltip .pricing-tooltiptext {
            visibility: hidden;
            background-color: black;
            line-height: 1.5em;
            font-size:12px;
            min-width: 300px;
            color: rgb(253, 252, 252);
            padding: 10px;
            border-radius: 6px;
            position: absolute;
            z-index: 5;
            text-align: center;
        }

        .pricing-tooltiptext .body{
            font-weight:100;
        }

        .pricing-tooltip:hover .pricing-tooltiptext {
            visibility: visible;
        }

        .pricing-dotted-border{
            border-bottom: 1px dotted black;
        }
        .pricing-tooltip-class,.pricing-tooltip-class:hover{
            color:black;
            border-bottom: 1px dotted black;
        }
        .pricing-tooltip-class:focus{
            color:black;
            text-decoration: none;
        }

        .toggle-div{
            cursor: pointer;
            font-size:1.5em;
        }

        .toggler_more{
            font-size: 1.1em;
            font-weight: bold;

            cursor: pointer;
        }

        .cd-pricing-features>li>a{
            color:#E97D68;
        }

        .pc-header{
            font-size:18px;
        }

        .cd-row .col-md-4, .cd-row .col-md-6 {
            padding-left: 30px!important;
            font-size: 16px;
            padding: 4px;
        }

        .cd-row .col-md-6 {
            width: 60.33333333%;
        }


        .ribbon {
            font-size: 12px !important;
            /* This ribbon is based on a 16px font side and a 24px vertical rhythm. I've used em's to position each element for scalability. If you want to use a different font size you may have to play with the position of the ribbon elements */

            width: 8%;

            position: relative;
            background: #ba89b6;
            color: #fff;
            text-align: center;
            padding-top: 8px; /* Adjust to suit */
            padding-bottom: 8px;
            margin: 2em auto 3em; /* Based on 24px vertical rhythm. 48px bottom margin - normally 24 but the ribbon 'graphics' take up 24px themselves so we double it. */
        }
        .ribbon:before, .ribbon:after {
            content: "";
            position: absolute;
            display: block;
            bottom: -1em;
            border: 15px solid #986794;
            z-index: -1;
        }
        .ribbon:before {
            left: -2em;
            border-right-width: 1.5em;
            border-left-color: transparent;
        }
        .ribbon:after {
            right: -2em;
            border-left-width: 1.5em;
            border-right-color: transparent;
        }
        .ribbon .ribbon-content:before, .ribbon .ribbon-content:after {
            content: "";
            position: absolute;
            display: block;
            border-style: solid;
            border-color: #804f7c transparent transparent transparent;
            bottom: -1em;
        }
        .ribbon .ribbon-content:before {
            left: 0;
            border-width: 0em 0 0 1em;
        }
        .ribbon .ribbon-content:after {
            right: 0;
            border-width: 0em 1em 0 0;
        }
        .ribbon-placement-1{
            margin-left: -34%;
            position: relative;
            margin-bottom: -80px;
            z-index: 1;
        }

        .ribbon-placement-2{
            margin-left: 34%;
            position: relative;
            margin-bottom: -60px;
            z-index: 1;
        }

        .popover {
            max-width: 25%;
            width: 25%;
            border-radius: 5px;
        }
        .popover-header{ background: rgb(233, 125, 104); color: white;}
        .PricingCard-row
        {padding:16px 0;-ms-flex-align:center;align-items:center;background-color:#fff;border-bottom:2px solid #e4e4e4;display:-ms-flexbox;display:flex}
        .PricingCard-column{padding:0 32px;width:calc(50% - 170px)}
        .PricingCard-column:first-child{width:340px}
        .PricingCard.four-wide{margin:0 0 20px}
        .PricingCard.four-wide .PricingCard-column
        {width:calc(65%/3);display:-ms-flexbox;display:flex;-ms-flex-direction:column;flex-direction:column}

        .has-checkmark
        {
            background:url(/sites/all/themes/Okta/images/pricing/icon--check.svg) no-repeat center;content:"";display:inline-block;height:24px;vertical-align:middle;width:16px;
        }        
        .entire{
            background:#ebf7f3;
        }
        table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}
.highlight {
    background-color: cyan;
    font-weight: bold;
}


th, td {
  /* text-align: center;
  font-size: 17px;
    width: 23%; */
   padding-left:3px;
    text-align: center;
    font-size: 14px;
    /* width: 7%; */
    width:2%;
    font-weight: 600;
    height: 30px;

}
/* .features{
  

    padding-left: 3px;
   
    font-size: 16px;
   
    width: 24.9%;
    font-weight: 600;
    height: 30px;

} */

.FeatureList>td {
  /* text-align: center;
  font-size: 17px;
    width: 23%; */
   /* padding-left:3px;
    text-align: center;
    font-size: 18px;
    width: 35%;
    font-weight: 600;
    height: 30px; */

}

th:first-child, td:first-child {
  text-align: left;
}

tr:nth-child(even) {
  background-color:#f2f5f8;
}

.fa-check {
  color: blue;
}

.fa-remove {
 display:none;
}
.activeCurrent {
  background-color:#e97d68;
  color: white;
  border-radius: 3px;
    display: inline-block;
    
    height: auto;
    /* color: blue; */
    
     vertical-align: top;
    position: relative;
    /* overflow: hidden; */
   /* box-shadow: 0 5px 4px rgba(0, 0, 0, 0.24), 0 5px 6px rgba(0, 0, 0, 0.12);
    transition:all 0.9s cubic-bezier(0.3, 0.6, 0.2, 1.8); */
    /* box-shadow: 0 11px 9px rgba(10, 0, 0, 0.24), 0 11px 9px rgba(10, 0, 0, 0.12),0 15px 14px rgba(0, 0, 0, 0.24); */
    box-shadow: 0 8px 20px  rgba(10, 0, 0, 0.5), 0 6px 11px rgba(10, 0, 0, 0.5),0 15px 14px rgba(0, 0, 0, 0.24);
    /* transition:all 0.9s cubic-bezier(0.4, 0.7, 0.3, 1.9); */
     transition:all 0.9s cubic-bezier(0.3, 0.3, 0.3, 1.0);
    width: 100%;
    /* border: 0px solid #e97d68;  */
    
   
}
.activeCurrentPlan {
    cursor:pointer;
  background-color:#e97d68;
  color: white;
  border-radius: 3px;
    display: inline-block;
    
    height: auto;
    /* color: blue; */
    
     vertical-align: top;
    position: relative;
    /* overflow: hidden; */
   /* box-shadow: 0 5px 4px rgba(0, 0, 0, 0.24), 0 5px 6px rgba(0, 0, 0, 0.12);
    transition:all 0.9s cubic-bezier(0.3, 0.6, 0.2, 1.8); */
    /* box-shadow: 0 11px 9px rgba(10, 0, 0, 0.24), 0 11px 9px rgba(10, 0, 0, 0.12),0 15px 14px rgba(0, 0, 0, 0.24); */
    box-shadow: 0 8px 20px  rgba(10, 0, 0, 0.5), 0 6px 11px rgba(10, 0, 0, 0.5),0 15px 14px rgba(0, 0, 0, 0.24);
    /* transition:all 0.9s cubic-bezier(0.4, 0.7, 0.3, 1.9); */
     transition:all 0.9s cubic-bezier(0.3, 0.3, 0.3, 1.0);
    width: 2%;
    /* border: 0px solid #e97d68;  */
    
   
}

.activeCurrentPlan td{
    color:#e97d68;
}

.activeSupport {
  background-color:#e97d68;
  color: white;
  border-radius: 3px;
    display: inline-block;
    
    height: auto;
    /* color: blue; */
    
     vertical-align: top;
    position: relative;
    /* overflow: hidden; */
   /* box-shadow: 0 5px 4px rgba(0, 0, 0, 0.24), 0 5px 6px rgba(0, 0, 0, 0.12);
    transition:all 0.9s cubic-bezier(0.3, 0.6, 0.2, 1.8); */
    /* box-shadow: 0 11px 9px rgba(10, 0, 0, 0.24), 0 11px 9px rgba(10, 0, 0, 0.12),0 15px 14px rgba(0, 0, 0, 0.24); */
    box-shadow: 0 8px 20px  rgba(10, 0, 0, 0.5), 0 6px 11px rgba(10, 0, 0, 0.5),0 15px 14px rgba(0, 0, 0, 0.24);
    /* transition:all 0.9s cubic-bezier(0.4, 0.7, 0.3, 1.9); */
     transition:all 0.9s cubic-bezier(0.3, 0.3, 0.3, 1.0);
    width: 100%;
    /* border: 0px solid #e97d68;  */
    
   
}
.activeDisabled {
  /*background-color:#d3d3d3;*/
  color: black;
  border-radius: 3px;
    display: inline-block;
    
    height: auto;
    /* color: blue; */
    
     vertical-align: top;
    position: relative;
    /* overflow: hidden; */
   /* box-shadow: 0 5px 4px rgba(0, 0, 0, 0.24), 0 5px 6px rgba(0, 0, 0, 0.12);
    transition:all 0.9s cubic-bezier(0.3, 0.6, 0.2, 1.8); */
    /* box-shadow: 0 11px 9px rgba(10, 0, 0, 0.24), 0 11px 9px rgba(10, 0, 0, 0.12),0 15px 14px rgba(0, 0, 0, 0.24); */
    /*box-shadow: 0 8px 20px  rgba(10, 0, 0, 0.5), 0 6px 11px rgba(10, 0, 0, 0.5),0 15px 14px rgba(0, 0, 0, 0.24);*/
    /* transition:all 0.9s cubic-bezier(0.4, 0.7, 0.3, 1.9); */
     transition:all 0.9s cubic-bezier(0.3, 0.3, 0.3, 1.0);
    width: 100%;
    /* border: 0px solid #e97d68;  */
    
   
}

/* .activeCurrent p{
    color:white;
} */
.activeCurrent h3{
    color:white;
}
.activeCurrent span{
    color:white;
}
.activeCurrent h2{
    color:white;
    font-weight:normal;
}
.activeSupport h3{
    color:white;
}
.activeSupport span{
    color:white;
}
.activeSupport h2{
    color:white;
    font-weight:normal;
}
.activeDisabled h3{
    color:black;
}
.activeDisabled span{
    color:#636363;
}
.activeDisabled h2{
    color:#636363;
}

.activeDisabled .action__text{
    color: #ffffff;
}
/* .cart_text{
    content:"redddddddddddd";
    color:red;
} */
.cart_text_changed{
    display:none;
    
    
}

.cart_text{
    font-size: 15px;

}
.activeCurrent .cart_text_changed
{
    color:white;
}
.activeSupport .support_text_changed
{
    color:white;
}
.support_text_changed{
    display:none;
    
    
}
.support_text{
    font-size: 15px;

}
.activeCurrent p{
    
    color:white;
    display:none;
}
.activeSupport p{
    
    color:white;
    display:none;
}
.activeCurrent h4{

    color:white;
    display:block;
    font-size: 15px;
    height: 22px;

}

.activeCurrent button{
border-radius: 6px 6px 0px 0px !important;
}

.activeCurrent .removeAddon {
border-radius: 6px 6px 0px 0px !important;    
display:block;
}
.activeCurrent .actionAddon {
display:none;
}
.activeCurrent .cd-currency{
    color:white;
}

.activeSupport h4{

color:#e97d68;
display:block;
font-size: 13px;
height: 22px;

}
.activeSupport button{
border-radius: 6px 6px 0px 0px !important;
}

.activeSupport .removeAddon {
border-radius: 6px 6px 0px 0px !important;    
display:block;
}
.activeSupport .actionAddon {
display:none;
}
.activeSupport .cd-currency{
color:white;
}


.activeDisabled p{
    
    color:#636363;
    display:none;
}
.activeDisabled h4{

    color:#d3d3d3;
    display:block;
    font-size: 15px;
    height: 22px;

}
.activeDisabled button{
border-radius: 6px 6px 0px 0px !important;
}

.activeDisabled .removeAddon {
border-radius: 6px 6px 0px 0px !important;    
display:block;
}
.activeDisabled .actionAddon {
display:none;
}
.activeDisabled .cd-currency{
    color:rgba(23, 61, 80, 0.4);
}

.activeCurrentAddon p{
    
    color:white;
    display:none;
}
.activeCurrentAddon h4{

    color:#e97d68;
    display:block;
    font-size: 15px;
    height: 22px;

}
.activeCurrentAddon button{
border-radius: 6px 6px 0px 0px !important;
}

.activeCurrentAddon .removeAddon {
border-radius: 6px 6px 0px 0px !important;    
display:block;
}
.activeCurrentAddon .actionAddon {
display:none;
}
.activeCurrentAddon .cd-currency{
    color:white;
}




.column.column-1-3 {
    /* width: 33.333333333%;
    margin-left: 780px; */
    width: 66%;
    margin-left: 70px;
    position: inherit;
    

}
#order-summary table tfoot tr:first-child td {
    padding-top: 0.5em;
    border-top: solid 1px #9f9fa0;
}
#order-summary table td {
    text-align: left;
    padding-bottom: 0.5em;
    border: 0;
    background: none;
}
table th, table td, .table th, .wf-table th, .table td, .wf-table td {
    padding: 10px;
}
table, .table, .wf-table {
    text-align: center;
    width: 100%;
    border-spacing: 0;
    background-color: #fff;
    margin-top:0px;

}
.color-red, .txt-red {
    color: #9e0000;
}
#selectInstances,#selectInstancesP,#selectInstancesE,#selectInstancesA,#InstanceCountE,#InstanceCountA
{
    /* width: 90px; */
    width: 44%;
    position: absolute;
    margin-top: -4px;
    margin-left: 4px;
}
.selectInstancesClass
{
    /* width: 90px; */
    width: 44%;
    position: absolute;
    margin-top: -4px;
    margin-left: 4px;
}

.special{
    background-color:gold;
padding-right: 12px;
    padding-top: 2px;
    padding-bottom: 3px;
    padding-left: 0px;
    padding-bottom: -27px;
    position: absolute;
    top: 3%;
    right: -13px;
    font-size: 13px;
    /* font-weight: bold; */
    color: #fff;
    /* text-transform: uppercase; */
    /* background: #33444e; */
    transform: 360;
    transform: rotate(270deg);
    height: 34px;
}

.popular {
    /* padding-left: 10px;
    padding: top;
    padding-top: 6px;
    padding-bottom: 6px; */
    padding-left: 8px;
   
    padding-top: 6px;
    padding-bottom: 6px;
    color: black;
    font-weight: 500;
}


.special:before {
    content: "";
    border-left: 11px solid transparent;
    border-top: 18px solid gold;
    border-bottom: 16px solid gold;
    position: absolute;
    left: -10px;
    top: 0px;
    transform: rotate(360deg);
}
.special:before {
    /* border-left-color: transparent;
    border-top-color: #139fec;
    border-bottom-color: #139fec; */
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}

.special:after {
    content: "";
    border-bottom: 5px solid #0000;
    border-left: 9px solid #121C1C;
    position: absolute;
    right: 0;
    top: 100%;
}
.special:after {
    border-left-color: #294f67;
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}

.specialTag{
    background-color: gold;
    padding-right: 46px;
    padding-top: 2px;
    padding-bottom: 28px;
    padding-left: 0px;
    padding-bottom: -27px;
    position: absolute;
    top: -10%;
    right: 93px;
    font-size: 14px;
    /* font-weight: bold; */
    color: #fff;
    /* text-transform: uppercase; */
    /* background: #33444e; */
    transform: 360;
    transform: rotate(360deg);
    height: 34px;
}

.popularTag {
    /* padding-left: 10px;
    padding: top;
    padding-top: 6px;
    padding-bottom: 6px; */
    padding-left: 8px;
   
    padding-top: 6px;
    padding-bottom: 6px;
    color: black;
    font-weight: 500;
}


.specialTag:before {
    content: "";
    border-left: 11px solid transparent;
    border-top: 18px solid gold;
    border-bottom: 16px solid gold;
    position: absolute;
    left: -10px;
    top: 0px;
    transform: rotate(360deg);
}
.specialTag:before {
    /* border-left-color: transparent;
    border-top-color: #139fec;
    border-bottom-color: #139fec; */
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}

.specialTag:after {
    content: "";
    border-bottom: 5px solid #0000;
    border-left: 9px solid #121C1C;
    position: absolute;
    right: 0;
    top: 100%;
    
}
.specialTag:after {
    border-left-color: #294f67;
}
:after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}


.plan_name{

    color: #2f6062;
    font-weight: bold;
    height:30px;


}
.plan_name_alt{

    color:#2f6062;
    font-weight: bold;

}
.instanceClass{
    /* color:black;
    font-size:14px */
    color: black;
    font-size: 14px;
   
    /* padding-right: 87px; */
    float: left;
    padding: 20px;
    }

.numberIDP{
    color:black;
    font-size:14px;
    /* padding-right: 76px;
    padding-left: 19px; */
    padding-right: 99px;
    padding-left: 15px;
}
.numberIDPAddon{
    color:black;
    font-size:14px;
    padding-right: 10%;
    padding-left: 10%;
}
.numberIDPThirdPartyAddon{
    color:black;
    font-size:14px;
    padding-right: 0%;
    padding-left: 0%;
}
.subheading_plan{
    text-align:center;
    color:black;
    font-weight: 500;
    font-size:15px;
    position:absolute;
    line-height:normal;
   /* padding-left: 17%;
    padding-right: 16%;*/
    padding: 5px;
}
.subheading_plan_alt{
   text-align:center;
    color:black;
    font-weight: 500;
    font-size:18px;
    position:absolute;
    line-height:normal;
    padding-left: 8%;
    padding-right: 8%;

}
.action {
    display: inline-block;
    font-size: 1.5em;
    white-space: nowrap;
    padding: 0.85em 1.25em;
    cursor: pointer;
    border: none;
    /* background: #e97d68; */
    text-align: center;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center;
    width: 100%;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    position: relative;
    /* margin-bottom: 1em; */
    background: #2f6062;
    font-weight:600;
    color: #fff;
    border-radius: 6px 6px 6px 6px !important;
    -webkit-transition: background 0.2s;
    transition: background 0.2s;
    margin-top: 0px;
}
.actionAddon {
    display: inline-block;
    font-size: 1.5em;
    white-space: nowrap;
    padding: 0.85em 1.25em;
    cursor: pointer;
    border: none;
    /* background: #e97d68; */
    text-align: center;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center;
    width: 100%;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    position: relative;
    /* margin-bottom: 1em; */
    background: #2f6062;
    font-weight:600;
    color: #fff;
    border-radius: 6px 6px 6px 6px !important;
    -webkit-transition: background 0.2s;
    transition: background 0.2s;
    margin-top: 0px;
}
.removeAddon{
    display:none;
    font-size: 1.5em;
    white-space: nowrap;
    padding: 0.85em 1.25em;
    cursor: pointer;
    border: none;
    /* background: #e97d68; */
    text-align: center;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center;
    width: 100%;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    position: relative;
    /* margin-bottom: 1em; */
    background: #2f6062;
    font-weight:600;
    color: #fff;
    border-radius: 6px 6px 6px 6px !important;
    -webkit-transition: background 0.2s;
    transition: background 0.2s;
    margin-top: 0px;
}
.hideOption{
    display:none;
    font-size: 1.5em;
    white-space: nowrap;
    padding: 0.85em 1.25em;
    cursor: pointer;
    border: none;
    /* background: #e97d68; */
    text-align: center;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center;
    width: 100%;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    position: relative;
    /* margin-bottom: 1em; */
    background: cadetblue;
    font-weight:600;
    color: #fff;
    border-radius: 6px 6px 6px 6px !important;
    -webkit-transition: background 0.2s;
    transition: background 0.2s;
    margin-top: 0px;
}
.unavailable{
    display: none;
    font-size: 1.5em;
    white-space: nowrap;
    /* padding: 0.85em 1.25em; */
    cursor: pointer;
    border: none;
    /* background: #e97d68; */
    text-align: center;
    -webkit-align-self: center;
    -ms-flex-item-align: center;
    align-self: center;
    width: 100%;
    -webkit-flex: none;
    -ms-flex: none;
    flex: none;
    position: relative;
    /* margin-bottom: 1em; */
    background: #2f6062;
    font-weight:600;
    color: #fff;
    border-radius: 6px 6px 6px 6px !important;
    -webkit-transition: background 0.2s;
    transition: background 0.2s;
    margin-top: 0px;

}
.third-party-title
{
    text-align: left;
    font-weight: 500;
    padding-top: 8px;
    /* style="font-size: 32px;text-align:left;padding-top: 30px;" */
}

.activeCurrentPlan {
    cursor:pointer;
  background-color:#e97d68;
  color: white;
  border-radius: 3px;
    display: inline-block;
    
    height: auto;
    /* color: blue; */
    
     vertical-align: top;
    position: relative;
    /* overflow: hidden; */
   /* box-shadow: 0 5px 4px rgba(0, 0, 0, 0.24), 0 5px 6px rgba(0, 0, 0, 0.12);
    transition:all 0.9s cubic-bezier(0.3, 0.6, 0.2, 1.8); */
    /* box-shadow: 0 11px 9px rgba(10, 0, 0, 0.24), 0 11px 9px rgba(10, 0, 0, 0.12),0 15px 14px rgba(0, 0, 0, 0.24); */
    box-shadow: 0 8px 20px  rgba(10, 0, 0, 0.5), 0 6px 11px rgba(10, 0, 0, 0.5),0 15px 14px rgba(0, 0, 0, 0.24);
    /* transition:all 0.9s cubic-bezier(0.4, 0.7, 0.3, 1.9); */
     transition:all 0.9s cubic-bezier(0.3, 0.3, 0.3, 1.0);
    width: 2%;
    /* border: 0px solid #e97d68;  */
    
   
}
.activeCurrentPlan .support_text_changed{
        display:block;
        color:white;
}
.activeCurrentPlan .support_text{
    display:none;
}
.responsive-table .activeCurrentPlan{
    background-color :white;
    Color: black;
}
.support_text_changed{
    display:none;
    
    
}

.individual-container-integration-addon{

    /* height:100%; */
} 

.addonTitle{

    margin-bottom: 10px;
}
.actionSupport{
   
   /* display: inline-block; */
   /* font-size: 1.5em; */
   /* white-space: nowrap; */
   padding:  1.15em 1.85em;
   cursor: pointer;
   height: 100%;
   border: none;
   /* background: #e97d68; */
   text-align: center;
   -webkit-align-self: center;
   -ms-flex-item-align: center;
   align-self: center;
   width: 100%;
   -webkit-flex: none;
   -ms-flex: none;
   flex: none;
   /* position: relative; */
   /* margin-bottom: 1em; */
   background: #2f6062;
   font-weight: 600;
   color: #fff;
   /* border-radius: 6px 6px 6px 6px !important; */
   -webkit-transition: background 0.2s;
   transition: background 0.2s;
   margin-top: 0px;
   

}
.supportRow{
   padding:0px;
   border-radius:5px;

}
.popular,.special:after {
    
    display:none;
}
.special:before,.special {
    display:none;
}

.cd-select-plans{
text-align: center;display:inherit
}


.ldap-addon-box{
    box-shadow: 6px 3px 18px 3px #b4bfc1;
        border: 0.9px solid #c3bbbb;
}

.mo_ldap_wrapper {
 display: grid;
 grid-template-columns: repeat(5, 1fr);
 grid-gap: 10px;
}

.ldap-plan-title{
    background: #d4d8d9;
    padding: 15px;
    text-align: center;
}

.cd-pricing-container{
max-width: 80%;
}
 .activeDisabled .hideOption{
        display:block;
    }
    
    .activeDisabled .removeAddon{
        display:none;
    }
    .activeDisabled .actionAddon{
        display:none;
    }

.cd-pricing-switcher {
           text-align: center;
       }
       .cd-pricing-switcher .fieldset {
           display: inline-block;
           position: relative;
           border-radius: 50em;
           border: 1px solid #266184;
       }
       .cd-pricing-switcher input[type="radio"] {
           position: absolute;
           opacity: 0;
       }
       .cd-pricing-switcher input[type="radio"] + label {
           position: relative;
           z-index: 1;
           display: inline-block;
           float: left;
           width: 160px;
           height: 44px;
           line-height: 40px;
           cursor: pointer;
           font-size: 1.4rem;
           color: #FFFFFF;
           font-size:18px;
       }
       
       .cd-pricing-switcher input[type="radio"]:checked + label  {
           /* use label:nth-of-type(n) to fix a bug on safari with multiple adjacent-sibling selectors*/
            top: 2px;
           left: 2px;
           height: 40px;
           width: 160px;
           background-color: black;
           border-radius: 50em;
           -webkit-transition: -webkit-transform 0.5s;
           -moz-transition: -moz-transform 0.5s;
       }
.license-steps{
font-size: 12px;
line-height: 25px;
}
.moldap-modal-contatiner-contact-us{
    top: 0;
    left: 0;
    position: fixed;
    width: 100%!important;
    background-color: #121212cc!important;
    opacity: .9!important;
    height: 100%!important;
    z-index: 10;
}

}
    </style>

<div style="text-align: center; font-size: 14px; color: white; padding-top: 4px; padding-bottom: 4px; border-radius: 16px;"></div>
    <input type="hidden" id="mo_license_plan_selected" value="licensing_plan" />
    <div class="tab-content">
        <div class="tab-pane active text-center" id="cloud">
            <div class="cd-pricing-container cd-has-margins"><br>
                <div class="ldap_center_div" style="text-align: center;">
                <div class="ldap_heading" style="display: inline-block;"><br>
                    <?php
                    update_option('mo_ldap_license_flag',1);
                    ?>
                <h1 style="font-size: 32px ; margin-right: 105px; ">Choose Your Licensing Plan</h1><br>
                <h4 style="font-size: 20px ; color: red; margin-right: 100px;">Are you not able to choose your plan? <a name="licensingContactUs" href="#licensingContactUs">(Contact Us)</a></h4>
            </div></div>
            <br>

                <div class="PricingCard-toggle ldap-plan-title" style="padding: unset">
                    <button class="PricingCard-toggle" type="button" onclick="onVidClose()" data-toggle="collapse" id="VidCollapse_top" data-target="#vidcollapse" aria-expanded="false" aria-controls="vidcollapse" style="color:black">
                        <span style="font-size: 17px;">Collapse Premium Version - Features & Instructions</span> &nbsp;<i class="fa fa-angle-double-up vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>
                    </button>
                </div>

                <div class="collapse" id="vidcollapse">
                   <br><br>
                <center><iframe width="560" height="315" src="https://www.youtube.com/embed/r0pnB2d0QP8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center><br>
                </div>

                <br>

                <div class="PricingCard-toggle ldap-plan-title" style="padding: unset">
                    <button class="PricingCard-toggle" type="button" onclick="onTermsClose()" data-toggle="collapse" id="termCollapse_top" data-target="#vidcollapse" aria-expanded="false" aria-controls="vidcollapse" style="color:black">
                        <span style="font-size: 17px;">Collapse Instances/Subsites: Terms and Definitions</span> &nbsp;<i class="fa fa-angle-double-up vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>
                    </button>
                </div>

                <div class="collapse" id="termcollapse">
                <br>
                    <p><h3>What is an instance?</h3><br>A WordPress instance refers to a single installation of a WordPress site. It refers to each individual website where the plugin is active. In the case of a single site Wordpress, each website will be counted as a single instance. <br><br>
                        For example, You have 3 sites hosted like one each for development, staging, and production. This will be counted as 3 instances.</p><br>
                    <p><h3>What is a multisite network?</h3> <br>A multisite network means managing multiple sites within the same WordPress installation and has the same database. <br><br>For example, You have 1 Wordpress instance/site with 3 subsites in it then it will be counted as 1 instance with 3 subsites.<br>
                        You have 1 WordPress instance/site with 3 subsites and another Wordpress instance/site with 2 subsites then it will be counted as 2 instances with 3 subsites.</p>
                <br>
            </div>
            <br>

            <div class="PricingCard-toggle ldap-plan-title" style="padding: unset; height: 50px;">
                <h2 class="PricingCard-toggle" style="color:black; padding-top: 15px;">LDAP Multiple Directories Plan</h2>
                </h2>
                </div>

            <div>
                <br>
                <p><h3>Looking for LDAP Authentication against more than one LDAP Server?</h3><br>We do support LDAP authentication from multiple LDAP directories in our Multiple LDAP Directories Plan. To get more details on this plan please <a name="MultipleDirContactUs" href="#MultipleDirContactUs">contact us</a>.</p>
                <br><br>
            </div>
                <br>
                <br>

            <script> jQuery('a[name=MultipleDirContactUs]').click(
                    function(){
                        jQuery('#licensingContactUsModal').show();
                        jQuery("#contact_us_title").text("Contact Us for LDAP Multiple Directories Premium Plan");
                        query = "Hi!! I am interested in LDAP Multiple Directories Premium Plan and want to know more about it.";
                        jQuery("#mo_ldap_licensing_contact_us #query").val(query);
                    });

                jQuery('#multiple_ldap_directories_contact_us_close').click(
                    function(){
                        jQuery("#mo_ldap_licensing_contact_us #query").val('');
                        jQuery('#licensingContactUsModal').hide();
                    });
            </script>

                <div class="cd-pricing-switcher">
                    <p class="fieldset" style="background-color: #e97d68;">
                        <input type="radio" name="sitetype" value="singlesite" id="singlesite" checked>
                        <label for="singlesite">Single Site</label>
                        <input type="radio" name="sitetype" value="multisite" id="multisite">
                        <label for="multisite">Multisite Network</label>
                    </p>
                </div>

            <script>
                jQuery(document).ready(function(){
                        
                    $ldap = jQuery;

                    //to change the active class for Addons
                    $ldap(".individual-container-addons").click(function(){
                        $ldap('.individual-container-addons').addClass('activeCurrent');
                        $ldap('.individual-container-addons').not(this).removeClass('activeCurrent');
                    })

                    $ldap("#singlesite_plans > .ldap_li select").click(function(e){
                       return false;
                    });

                    $ldap("#multisite_plans > .ldap_li_mul select").click(function(e){
                        return false;
                    });

                    //to change the active class for singleSitePlans
                   $ldap("#singlesite_plans > .ldap_li").click(function(e){
                    var selectElemID = $ldap(this).find("li[data-type='singlesite']").attr("id").toLowerCase();
                    if(selectElemID.includes("pricing"))
                        return true;
                        $ldap('.ldap_li').find(".individual-container").addClass('activeCurrent');
                        $ldap('.ldap_li').not(this).find(".individual-container").removeClass('activeCurrent');

                   })
                   //to change the active class for multiSitePlans
                   $ldap("#multisite_plans > .ldap_li_mul").click(function(e){
                    var selectElemID = $ldap(this).find("li[data-type='multisite']").attr("id").toLowerCase();
                    if(selectElemID.includes("pricing"))
                        return true;
                        $ldap('.ldap_li_mul').find(".individual-container").addClass('activeCurrent');
                        $ldap('.ldap_li_mul').not(this).find(".individual-container").removeClass('activeCurrent');

                   })
                });

               var selectArray = JSON.parse('<?php echo json_encode(new MoLicensePlansPricing()) ?>');

        function createSelectOptions(elemId){

            var selectPricingArray = selectArray[elemId];
            var selectElem = ' <div class="cd-price"><span class="cd-currency">$</span><span class="cd-value" id="standardID">'+selectArray[elemId]["1"]+'</span></span></div>'+
                            '<span style="font-size:15px">(One Time Payment)</span></header> <!-- .cd-pricing-header --></a>'+
                            '<footer class="cd-pricing-footer"><h3 class="instanceClass" >No. of instances:';
            var selectElem = selectElem + ' <select class="selectInstancesClass" required="true" onchange="changePricing(this)" id="'+elemId+'">';
            jQuery.each(selectPricingArray,function(instances,price){
                selectElem = selectElem + '<option value="'+instances+'" data-value="'+instances+'">'+instances+' </option>';
            })
            selectElem = selectElem + "</select>";
            return document.write(selectElem);
        }       

        function createSelectWithSubsitesOptions(elemId){
            var selectPricingArray = selectArray[elemId];
            var selectSubsitePricingArray = selectArray['subsiteIntances'];
            var selectElem = ' <div class="cd-price"><span class="cd-currency">$</span><span class="cd-value" id="standardID">'+selectArray[elemId]["1"]+'</span></span></div>'+
                            '<span style="font-size:15px">(One Time Payment)</span></header> <!-- .cd-pricing-header --></a>'+
                            '<footer class="cd-pricing-footer"><div style="display: inline-block;float: left;"><h3 class="instanceClass" >No. of instances:';
            var selectElem = selectElem + ' <select class="selectInstancesClass" required="true" onchange="changePricing(this)" id="'+elemId+'">';
            jQuery.each(selectPricingArray,function(instances,price){
                selectElem = selectElem + '<option value="'+instances+'" data-value="'+instances+'">'+instances+' </option>';
            })
            selectElem = selectElem + "</select></h3>";
            selectElem = selectElem + '<br><h3 class="instanceClass" >No. of subsites:&nbsp&nbsp';
            selectElem = selectElem + '<select class="selectInstancesClass" required="true" onchange="changePricing(this)" id="'+elemId+'" name="'+elemId+'-subsite">';
             jQuery.each(selectSubsitePricingArray,function(instances,price){
                selectElem = selectElem + '<option value="'+instances+'" data-value="'+instances+'">'+instances+' </option>';
            })
                selectElem = selectElem + "</select></h3></div>";
            return document.write(selectElem);
        }

       function changePricing($this)
       {
        
        var selectId =  jQuery($this).attr("id");
        var selectSubsiteValue = jQuery("select[name="+selectId+"-subsite]").val();
        var e = document.getElementById(selectId);
        var strUser = e.options[e.selectedIndex].value;
        var strUserInstances = strUser != "UNLIMITED" ? strUser : 500; 
        
        selectArrayElement = [];
        selectSubsiteArrayElement = selectArray.subsiteIntances[selectSubsiteValue];
        
         if(selectId =="pricingCustomProfile")
            selectArrayElement = selectArray.pricingCustomProfile[strUser];
         if(selectId =="pricingKerberos")
            selectArrayElement = selectArray.pricingKerberos[strUser];
         if(selectId =="pricingEnterprise")
            selectArrayElement = selectArray.pricingEnterprise[strUser];
         if(selectId =="mulPricingCustomProfile")
            selectArrayElement = parseInt(selectArray.mulPricingCustomProfile[strUser].replace(",","")) + parseInt(parseInt(selectSubsiteArrayElement)*parseInt(strUserInstances));
         if(selectId =="mulPricingKerberos")
            selectArrayElement = parseInt(selectArray.mulPricingKerberos[strUser].replace(",","")) + parseInt(parseInt(selectSubsiteArrayElement)*parseInt(strUserInstances));
         if(selectId =="mulPricingEnterprise")
            selectArrayElement = parseInt(selectArray.mulPricingEnterprise[strUser].replace(",","")) + parseInt(parseInt(selectSubsiteArrayElement)*parseInt(strUserInstances));

            jQuery("#"+selectId).parents("div.individual-container").find(".cd-value").text(selectArrayElement);

       }
            </script>
            <div id="outer-main-block">
            <input type="hidden" value="<?php echo Mo_Ldap_Local_Util::is_customer_registered()?>" id="mo_customer_registered">
           <ul class="completeList">
            <ul class="cd-pricing-list cd-bounce-invert" >
                <div id="singlesite_plans" style="display: grid;    grid-template-columns: repeat(3, 1fr);grid-gap: 10px;">
                <li class="ldap_li">
                    <ul class="cd-pricing-wrapper">
                        <li  name="listPlans" data-type="singlesite" id="standard" class="mosslp" style="border: <?php echo $sspborder; ?>">
                        <div id="0" class="individual-container">
                        <a id="popover1" data-toggle="popover">
                            <header class="cd-pricing-header">
                                                    <h2 class="plan_name" style="margin-bottom: 10px" >Basic LDAP Authentication Plan<span style="font-si ze:0.5em"></span></h2><br><br>
                                <hr>
                                <div class="subheading">
                                                        <h3 class="subheading_plan">Sync user profile information and assign wordpress roles based on LDAP groups</h3>
                                </div>
                                <script> createSelectOptions('pricingCustomProfile'); </script>
                            </header>
                        </a>
                        </div>
                        </li>
                        <footer class="cd-pricing-footer">
                            <a href="#" class="cd-select cd-select-plans" onclick="upgradeform('wp_ldap_intranet_premium_plan')">Upgrade Now</a>
                        </footer>
                       
                        </li>
                    </ul> 
                </li>

                <li class="ldap_li">
               
                    <ul class="cd-pricing-wrapper ">
                        <li name="listPlans" data-type="singlesite" id="standard" class="mosslp" style="border: <?php echo $sseborder; ?>">
                        <div id="1" class="individual-container activeCurrent">
                        <a id="popover2" data-toggle="popover" >
                            <header class="cd-pricing-header">
                                <div class="special"><div class="popular">Popular</div></div>
                                                    <h2 class="plan_name" style="margin-bottom: 10px">Basic LDAP Authentication Plan + Kerberos/NTLM SSO</h2><br><br>
                                <hr>
                                <div class="subheading">
                                                        <h3   class="subheading_plan">All features along with auto-login (SSO) into your wordpress site on domain joined machine's</h3>
                                </div>
                                <script> createSelectOptions('pricingKerberos') </script>
                            </header>
                        </a>
                        </div>
                        </li>
                            <footer class="cd-pricing-footer">
                                <a href="#" class="cd-select cd-select-plans" onclick="upgradeform('wp_ldap_ntlm_sso_bundled_plan')">Upgrade Now</a>
                            </footer>
                                </ul>
                        </li>
                        <!-- ######################################## Enterprise/All-inclusive ############################-->

            <li class="ldap_li">
                    <ul class="cd-pricing-wrapper">
                        <li data-type="singlesite" id="standard" class="mosslp" style="border: <?php echo $sseborder; ?>">
                        <div id="2" class="individual-container ">
                           <a id="popover3" data-toggle="popover" >
                            <header class="cd-pricing-header">
                            <div class="special"><div class="popular">Popular</div></div>
                                                    <h2 class="plan_name" style="margin-bottom:10px;">Enterprise/All-Inclusive Plan</h2><br><br>
                                <hr>
                                <div class="subheading">
                                                        <h3 class="subheading_plan">All features along with access to all premium add-ons<br /><br /></h3>
                                </div>
                                <script> createSelectOptions('pricingEnterprise') </script>
                            </header>
                           </a>
                        </div>
                        </li>
                        <footer class="cd-pricing-footer">
                               <a href="#" class="cd-select cd-select-plans" onclick="upgradeform('wp_ldap_all_inclusive_bundled_plan')">Upgrade Now</a>
                        </footer>
                        </li>
                    </ul>
</div>

                    <!--##########################################MULTISITE PLANS######################################  -->
  <div id="multisite_plans" style=" display:none;grid-template-columns: repeat(3, 1fr);grid-gap: 10px;">
                <li class="ldap_li_mul">
                    <ul class="cd-pricing-wrapper">
                        <li  name="listPlans" data-type="multisite" id="multisite" class="momslp" style="border: <?php echo $sspborder; ?>">
                        <div id="0" class="individual-container">
                        <a id="popover1" data-toggle="popover">
                            <header class="cd-pricing-header">
                            <!-- <span class="specialTag"><div class="popularTag">Popular</div></span> -->
                                                    <h2 class="plan_name" style="margin-bottom: 10px" >Multisite Basic LDAP <br> Authentiction <br> Plan<span style="font-si ze:0.5em"></span></h2><br><br>
                                <hr>
                                <div class="subheading">
                                <h3  class="subheading_plan">Sync user profile information and assign wordpress roles based on LDAP groups<br /><br /></h3>
                                </div>
                                <script> createSelectWithSubsitesOptions('mulPricingCustomProfile');</script>

                            </header>
                        </a>
                        </div>
                        </li>
                        <footer class="cd-pricing-footer">
                            <a href="#" class="cd-select cd-select-plans" onclick="upgradeform('wp_ldap_intranet_multisite_premium_plan')">Upgrade Now</a>
                        </footer>
                        </li>
                    </ul> 
                </li>

                <li class="ldap_li_mul">
               
                    <ul class="cd-pricing-wrapper ">
                        <li name="listPlans" data-type="multisite" id="multisite" class="momslp" style="border: <?php echo $sseborder; ?>">
                        <div id="1" class="individual-container activeCurrent">
                        <a id="popover2" data-toggle="popover" >
                            <header class="cd-pricing-header">
                            
            <div class="special"><div class="popular">Popular</div></div>
                                                    <h2 class="plan_name" style="margin-bottom: 10px">Multisite Basic LDAP Authentication Plan + Kerberos/NTLM SSO</h2><br><br>
                                <hr>
                                <div class="subheading">
                                                        <h3   class="subheading_plan">All features along with auto-login (SSO) into your wordpress site on domain joined machine's<br /><br /></h3>
                                </div>
                                <script> createSelectWithSubsitesOptions('mulPricingKerberos') </script>
                            </header>
                        </a>
                        </div>
                        </li>
                        <footer class="cd-pricing-footer">
                            <a href="#" class="cd-select cd-select-plans" onclick="upgradeform('wp_ldap_ntlm_sso_multisite_bundled_plan')">Upgrade Now</a>
                        </footer>
                </li>
</ul>

                        <!-- ######################################## Enterprise/All-inclusive ############################-->

            <li class="ldap_li_mul">
                    <ul class="cd-pricing-wrapper">
                        <li data-type="multisite" id="multisite" class="momslp" style="border: <?php echo $sseborder; ?>">
                        <div id="2" class="individual-container ">
                           <a id="popover3" data-toggle="popover" >
                            <header class="cd-pricing-header">
                            <div class="special"><div class="popular">Popular</div></div>
                                                    <h2 class="plan_name" style="margin-bottom:10px;">Multisite Enterprise/All-Inclusive Plan</h2><br><br>
                                <hr>
                                <div class="subheading">
                                                        <h3 class="subheading_plan">All features along with access to all premium add-ons<br /><br /></h3>
                                </div>
                                <script> createSelectWithSubsitesOptions('mulPricingEnterprise') </script>
                            </header>
                           </a>
                        </div>
                        </li>
                        <footer class="cd-pricing-footer">
                               <a href="#" class="cd-select cd-select-plans" onclick="upgradeform('wp_ldap_all_inclusive_multisite_bundled_plan')">Upgrade Now</a>
                        </footer>
                        </li>
                    </ul>

</div>
</div>
</ul>
</div>
        


<script>

function onCloseChange(){

if(jQuery("#collapseExample").css("display")=="none"){
jQuery("#buttonToggleCollapse_top").html('Collapse Feature Comparison &nbsp;<i class="fa fa-angle-double-up vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>');
jQuery("#collapseExample").show();
}
else if(jQuery("#collapseExample").css("display")=="block")
{
jQuery("#collapseExample").hide();
jQuery("#buttonToggleCollapse_top").html('Feature Comparison &nbsp;<i class="fa fa-angle-double-down vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>');
}
}

function onVidClose(){

    if(jQuery("#vidcollapse").css("display")=="none"){
        jQuery("#VidCollapse_top").html('<span style="font-size:17px;">Collapse Premium Version - Features and Instructions</span> &nbsp;<i class="fa fa-angle-double-up vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>');
        jQuery("#vidcollapse").show();
    }
    else if(jQuery("#vidcollapse").css("display")=="block")
    {
        jQuery("#vidcollapse").hide();
        jQuery("#VidCollapse_top").html('<span style=font-size:17px;">Premium Version - Features and Instructions </span>&nbsp;<i class="fa fa-angle-double-down vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>');
    }
}
function onTermsClose(){

    if(jQuery("#termcollapse").css("display")=="none"){
        jQuery("#termCollapse_top").html('<span style="font-size:17px;">Collapse Premium Version - Features and Instructions</span> &nbsp;<i class="fa fa-angle-double-up vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>');
        jQuery("#termcollapse").show();
    }
    else if(jQuery("#termcollapse").css("display")=="block")
    {
        jQuery("#termcollapse").hide();
        jQuery("#termCollapse_top").html('<span style=font-size:17px;">Premium Version - Features and Instructions </span>&nbsp;<i class="fa fa-angle-double-down vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>');
    }
}

</script>
<style>


.grow {
  -moz-transition: height .5s;
  -ms-transition: height .5s;
  -o-transition: height .5s;
  -webkit-transition: height .5s !important;
  transition: height .5s !important;
  height: 0px;
  overflow: hidden;
}

.features-heading{
height:50px;
background: #e97d68;
color: #ffffff;
font-weight: 600;
}
.features{
 
  padding-left: 3px;
 
  font-size: 16px;
 
  width: 20%;
  font-weight: 530;
  height: 30px;

}

#feature_list th {
position: -webkit-sticky;
position: sticky;
top: 32px;
background: #e97d68;
}

.ldap-menu {
  /*position: absolute;*/
  /*clip: rect(0px 112px 175px 0px);*/
  transition: clip 60000ms ease-out;
}

.ldap-menu--collapsed {
  /*clip: rect(0px 70px 34px 0px);*/
}

</style>

        <div class="PricingCard-toggle ldap-plan-title" style="padding: unset;">
<button class="PricingCard-toggle" type="button" onclick="onCloseChange()" data-toggle="collapse" id="buttonToggleCollapse_top" data-target="#collapseExample     " aria-expanded="false" aria-controls="collapseExample" style="color:black">
Collapse Feature Comparison &nbsp;<i class="fa fa-angle-double-up vertical-align-bottom learn-more-angle" id="mfa-features-icon"></i>
 </button>
</div>

<div class="collapse" id="collapseExample">
    <table class="FeatureList">
<tr id="feature_list">
<th style="color: white;"> Features List </th>
<th style="color: white;"> Basic LDAP Authentication Plan </th>
<th style="color: white;"> Basic LDAP Authentication Plan + Kerberos/NTLM SSO </th>
<th style="color: white;"> Enterprise/All-Inclusive Plan </th>
</tr>
 
  <tr>
                    <td class="features">Custom WordPress Profile Mapping</td>
                    <td class="features"><i class="fa fa-check"></i></td>
                    <td class="features"><i class="fa fa-check"></i></td>
                    <td class="features"><i class="fa fa-check"></i></td>
                </tr>

                <tr>
                    <td class="features">Assign WordPress roles based on LDAP groups</td>
                    <td class="features"><i class="fa fa-check"></i></td>
                    <td class="features"><i class="fa fa-check"></i></td>
                    <td class="features"><i class="fa fa-check"></i></td>
                </tr>

                <tr>
                    <td class="features">Support for fetching LDAP groups automatically for role mapping</td>
                    <td class="features"><i class="fa fa-check"></i></td>
                    <td class="features"><i class="fa fa-check"></i></td>
                    <td class="features"><i class="fa fa-check"></i></td>
                </tr>
                <tr>
                    <td class="features">Authenticate users from Multiple LDAP Search Bases</td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
  </tr>
 
  <tr>
                    <td class="features">Support for automatic selection of LDAP OU's as a search base</td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
  </tr>
 
  <tr>
                    <td class="features">Automatic Custom Search filter builder with group restriction</td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
  </tr>
 
  <tr>
                    <td class="features">Authenticate users from both LDAP and WordPress</td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
  </tr>
 
  <tr>
                    <td class="features">WordPress to LDAP user profile update</td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
    <td class="features"><i class="fa fa-check"></i></td>
  </tr>

        <tr>
                    <td class="features">Auto-register of LDAP users in WordPress site</td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
        </tr>
        <tr>
            <td class="features">Redirect to custom URL after authentication</td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
        </tr>
        <tr>
                    <td class="features">Support for LDAPS for Secure Connection to LDAP Server</td>
                    <td class="features"><i class="fa fa-check"></i></td>
                    <td class="features"><i class="fa fa-check"></i></td>
                    <td class="features"><i class="fa fa-check"></i></td>
                </tr>
                <tr>
                    <td class="features">Detailed user authentication report</td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
        </tr>
        <tr>
            <td class="features">Support for Import/Export plugin configuration</td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
        </tr>
        <tr>
                    <td class="features">Auto-login (SSO) into WordPress site with Kerberos/NTLM</td>
            <td class="features"><i class="fa fa-times" aria-hidden="true" style="color: red"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
            <td class="features"><i class="fa fa-check"></i></td>
        </tr>
        <tr>
                    <td class="features">Access to all premium add-ons</td>
            <td class="features"><i style="color: red"></i>(Separate Purchase)</td>
            <td class="features"><i style="color: red"></i>(Separate Purchase)</td>
            <td class="features"><i class="fa fa-check"></i></td>
        </tr>
</table>
</div>
<br>
        <div class="cd-pricing-container cd-has-margins" style="max-width: unset"><br>
            <h1 class="third-party-title ldap-plan-title"><u>Premium Add-ons (Require <b>Basic LDAP Authentication Plan</b>)</u></h1></div><br>
            <input type="hidden" value="<?php echo Mo_Ldap_Local_Util::is_customer_registered();?>" id="mo_customer_registered">
                    <?php
                    $adddonObj = new MoAddonListContent();

                    $adddonObj->showAddonsContent();?>
    </div>
<br>
        <div class="tab-content ">
        <div style="text-align:left; font-size:12px; padding-left:30px; padding-right:30px;">
            <h3 class="ldap-plan-title">Steps to upgrade to premium plugin -</h3>
            <div id="license-steps" class="license-steps"><p>
            1. You will be redirected to miniOrange Login Console. Enter your password with which you created an account with us. After that you will be redirected to payment page.</br>
            2. Enter you card details and complete the payment. On successful payment completion, you will see the link to download the premium plugin.</br>
            3. Download the premium plugin.</br>
            4. From the Wordpress admin dashboard, delete the free plugin currently installed.</br>
            5. Unzip the premium plugin and extract the files.</br>
            6. Upload the extracted files of premium plugin using FTP to path.</br>
            <b><i>/wp-content/plugins/</i></b>
            Alternately, go to <b>Add New → Upload Plugin</b> in Plugin's menu to install the .zip directly.</br>
            7. Activate plugin and login to the plugin with the miniOrange account</br>
            8. From this point on, do not update the plugin from the Wordpress store. We will notify you when we upload a new version of the plugin.</br>
                </p></div>
            <br>
            <div id="license-refund-policy" class="license-steps">
            <h3 class="ldap-plan-title">10 Days Return Policy -</h3>
                <p>If the premium plugin you purchased is not working as advertised and you’ve attempted to resolve any feature issues with our support team, which couldn't get resolved, we will refund the whole amount within 10 days of the purchase. Note that this policy does not cover the following cases:
                <ul style="list-style-type:square;margin-left: 20px">
                    <li>Change of mind or change in requirements after purchase.</li>
                    <li>Infrastructure issues not allowing the functionality to work.</li>
                </ul>
                Please email us at <a href="mailto:info@xecurify.com">info@xecurify.com</a> for any queries regarding the return policy.</p><br>
            </div><br>
        </div>
    </div>


    <!-- Modal -->
    <?php
                            $current_user = wp_get_current_user();
                            if(get_option('mo_ldap_local_admin_email'))
                                $admin_email = get_option('mo_ldap_local_admin_email');
                            else
                                $admin_email = $current_user->user_email; ?>
    <div  hidden id="licensingContactUsModal" name="licensingContactUsModal" class="mo_ldap_modal" style="margin-left: 26%">
    <div class="moldap-modal-contatiner-contact-us" syle="color:black"></div>
        <!-- Modal content -->
        <div class="mo_ldap_modal-content" id="contactUsPopUp" style="width: 700px; padding:30px;">
            <span id="contact_us_title" style="font-size: 22px; margin-left: 50px; font-weight: bold;">Contact Us for Choosing the Correct Premium Plan</span>
            <form name="f" method="post" action="" id="mo_ldap_licensing_contact_us" style="font-size: large;">
                <input type="hidden" name="option" value="mo_ldap_login_send_feature_request_query"/>
                <div>
                    <p style="font-size: large;">
                        <br>
                        <b >Email: </b>
                        <input style=" width: 77%; margin-left: 69px; " type="email" class="mo_ldap_table_textbox" id="query_email" name="query_email" value="<?php echo $admin_email; ?>" placeholder="Enter email address through which we can reach out to you" required />
                        <br><br>
                        <b style="display:inline-block; vertical-align: top;">Description: </b>
                        <textarea style="width:77%; margin-left: 21px;" id="query" name="query" required rows="5" style="width: 100%"
                                  placeholder="Tell us which features you require"></textarea></p>
                        <br><br>
                    <div class="mo_ldap_modal-footer" style="text-align: center">
                        <input type="button" style="font-size: medium" name="miniorange_ldap_feedback_submit" id="miniorange_ldap_feedback_submit"
                               class="button button-primary button-small" onclick="validateRequirement()" value="Submit"/>
                        <input type="button" style="font-size: medium" name="miniorange_ldap_licensing_contact_us_close" id="miniorange_ldap_licensing_contact_us_close" class="button button-primary button-small" value="Close" />
                    </div>
                </div>
            </form>
        </div>

    </div>

    <form style="display:none;" id="loginform"
                 action="<?php echo get_option( 'mo_ldap_local_host_name' ). '/moas/login'; ?>"
                 target="_blank" method="post">
        <input type="email" name="username" value="<?php echo get_option( 'mo_ldap_admin_email' ); ?>"/>
        <input type="text" name="redirectUrl"
               value="<?php echo get_option( 'mo_ldap_local_host_name' ). '/moas/initializepayment'; ?>"/>
        <input type="text" name="requestOrigin" id="requestOrigin"/>
    </form>
   <a  id="mo_backto_ldap_accountsetup_tab" style="display:none;" href="<?php echo add_query_arg( array( 'tab' => 'account' ), htmlentities( $_SERVER['REQUEST_URI'] ) ); ?>">Back</a>

    <style>

        .btn_blue{
            padding:5px !important;
            width:150px;
        }

        .table-onpremisetable{
            width: 30%;
            padding-top: 100px;
            margin: auto;
            width: 40%;
            padding: 10px;
        }


        .table-onpremisetable2{
            padding-top: 100px;
            margin: auto;
            width:  60%;
            padding: 10px;
            border: 2px solid #fff;
            table-layout:fixed;
            color: #173d50;

        }

        .table-onpremisetable2 th {
            background-color: #fcfdff;

            text-align: center;
            vertical-align:center;
        }

        .table-onpremisetable2 td {
            background-color: #fcfdff;

            text-align: center;
            vertical-align:center;
        }


        /* the third */
        .table-plugin-pricing{
            margin: auto;
            width: 70%;
            padding: 30px;
            background-color: transparent;
            border-collapse: collapse;
            border-spacing: 0;
        }

      

        .give-some-space-dude{
            margin: 30px auto 45px;
        }


        .onpremise-container{
            color: black ;
            background-color: #fff !important;
        }

        .plugins-pricing{
            padding:50px;
            width:80%;
            margin: auto;
            background-color: inherit;
        }
        h1 {
            margin-bottom: .67em ;
            font-size: 2em;
        }
        .tab-content-plugins-pricing div {
            background: #173d50;
        }

        /* .onpremise-container{
            background-color: #fff !important;
        } */
        .color-make-black{
            color:black;
        }
        .tip-icon {
            display: inline-block;
            width: 15px;
            height: 15px;
            background-size: 100%;
            background-repeat: no-repeat;
            background-position: 50%;
            vertical-align: middle;
            margin: 0 0 2px 5px;
            opacity: .3;
        }
      
       

    </style>
    <script >
        
        jQuery('.popupCloseButton').click(function(){
            jQuery('.popup').hide();
        });

        jQuery('.popup').click(
            function(){
                jQuery('.popup').hide();
            });

        jQuery('a[name=licensingContactUs]').click(
            function(){
                // jQuery("#contactUsPopUp").show();
                jQuery('#licensingContactUsModal').show();
                jQuery("#contact_us_title").text("Contact Us for Choosing the Correct Premium Plan");
            });

        jQuery('#miniorange_ldap_licensing_contact_us_close').click(
            function(){
                // jQuery("#contactUsPopUp").hide();
                jQuery("#mo_ldap_licensing_contact_us #query").val('');
                jQuery('#licensingContactUsModal').hide();
            });


        jQuery(document).ready(function($){
$('#buttonToggleCollapseAddon').click(function(){

$('#buttonToggleAddon').show();

});


$('#buttonToggleThirdPartyAddon').click(function(){
$('#buttonToggleThirdPartyAddon').hide();

});
$('#buttonToggleCollapseThirdParyAddon').click(function(){

$('#buttonToggleThirdPartyAddon').show();

});



      
$('#sso-mfa-features').click(function(){

if($('#show-sso-mfa-features').hasClass('in')){ 
    
     $('#sso-mfa-features-icon').removeClass('arrow-rotate-180').addClass('arrow-rotate-zero');
     $('#sso-mfa-features').text('Show Features'); 
    
} else {
    
    $('#sso-mfa-features-icon').removeClass('arrow-rotate-zero').addClass('arrow-rotate-180');
    $('#sso-mfa-features').text('Collapse Features');
}


});  });
            
            function hideElements() {
            jQuery(document).ready(function($){

        
        var x = document.getElementById("myDIV");
        var toggle_button=document.getElementById("toggleBack");
            if (x.style.display === "block") {
                x.style.display = "none";
                toggle_button.style.display="none";
                $('#toggleBack').removeClass('PricingCard-toggle');
                $('#toggleBack').addClass('PricingCard-toggleBack');

            } 
        });
            }

            setTimeout(function () {
            var elmnt = document.getElementById("success");
            var elmnt1 = document.getElementById("error");
            if(elmnt1){
                jQuery(elmnt1).css("display","block");
                jQuery(elmnt1).css("margin-top","1%");
            }
            else if(elmnt){
                jQuery(elmnt).css("display","block");
                jQuery(elmnt).css("margin-top","1%");
            }
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;

        }, 60);

        function validateRequirement() {

                if(validateEmail()){
            var requirement = document.getElementById("query").value;
            if (requirement.length <= 10) {
                        alert("Please enter more details about your requirement");
            } else {
                document.getElementById("mo_ldap_licensing_contact_us").submit();
            }
        }
        }

        function validateEmail()
        {
            var email = document.getElementById('query_email');
            if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email.value))
            {
                return (true)
            }
            else
            {
                alert("You have entered an invalid email address!")
                return (false)
            }

        }

        function openSupportForm(planType){
            query = "Hi!! I am interested in "+planType+" Add-on and want to know more about it.";
            jQuery("#mo_ldap_licensing_contact_us #query").val(query);
            jQuery("a[name='licensingContactUs']").click();
        }

        function upgradeform(planType) {
            if(planType=="ContactUs")
                jQuery("a[name='licensingContactUs']").click();
            else{
            jQuery('#requestOrigin').val(planType);
            if(jQuery('#mo_customer_registered').val()==1)
                jQuery('#loginform').submit();
            else{
                location.href = jQuery('#mo_backto_ldap_accountsetup_tab').attr('href');
            }
        }

        }

        jQuery("input[name=sitetype]:radio").change(function() {

            if (this.value == 'multisite') {
                jQuery('#multisite_plans').addClass('is-visible').css("display","grid");
                jQuery('#singlesite_plans').removeClass('is-visible').css("display","none");

            }
            if(this.value == 'singlesite'){
                jQuery('#multisite_plans').removeClass('is-visible').css("display","none");
                jQuery('#singlesite_plans').addClass('is-visible').css("display","grid");

                // jQuery('.momslp#multisite').removeClass('is-visible').addClass('is-hidden');
                // jQuery('.mosslp#standard').addClass('is-visible').removeClass('is-hidden is-selected');
            }
        });

        jQuery(document).ready(function($){

            //document.getElementById("multisite").checked = true;
            if(jQuery('#mo_license_plan_selected').val() == 'multisite'){
                document.getElementById("multisite").checked = true;
            }
            if(document.getElementById("multisite").checked == true){
                jQuery('.mosslp').removeClass('is-visible').addClass('is-hidden');
                jQuery('.momslp').addClass('is-visible').removeClass('is-hidden is-selected');
            }

            //hide the subtle gradient layer (.cd-pricing-list > li::after) when pricing table has been scrolled to the end (mobile version only)
            checkScrolling($('.cd-pricing-body'));
            $(window).on('resize', function(){
                window.requestAnimationFrame(function(){checkScrolling($('.cd-pricing-body'))});
            });
            $('.cd-pricing-body').on('scroll', function(){
                var selected = $(this);
                window.requestAnimationFrame(function(){checkScrolling(selected)});
            });

            function checkScrolling(tables){
                tables.each(function(){
                    var table= $(this),
                        totalTableWidth = parseInt(table.children('.cd-pricing-features').width()),
                        tableViewport = parseInt(table.width());
                    if( table.scrollLeft() >= totalTableWidth - tableViewport -1 ) {
                        table.parent('li').addClass('is-ended');
                    } else {
                        table.parent('li').removeClass('is-ended');
                    }
                });
            }

            //switch from monthly to annual pricing tables
            bouncy_filter($('.cd-pricing-container'));

            function bouncy_filter(container) {
                container.each(function(){
                    var pricing_table = $(this);
                    var filter_list_container = pricing_table.children('.cd-pricing-switcher'),
                        filter_radios = filter_list_container.find('input[type="radio"]'),
                        pricing_table_wrapper = pricing_table.find('.cd-pricing-wrapper');

                    //store pricing table items
                    var table_elements = {};
                    filter_radios.each(function(){
                        var filter_type = $(this).val();
                        table_elements[filter_type] = pricing_table_wrapper.find('li[data-type="'+filter_type+'"]');
                    });

                    //detect input change event
                    filter_radios.on('change', function(event){
                        event.preventDefault();
                        //detect which radio input item was checked
                        var selected_filter = $(event.target).val();

                        //give higher z-index to the pricing table items selected by the radio input
                        show_selected_items(table_elements[selected_filter]);

                        //rotate each cd-pricing-wrapper
                        //at the end of the animation hide the not-selected pricing tables and rotate back the .cd-pricing-wrapper

                        // if( !Modernizr.cssanimations ) {
                        //     hide_not_selected_items(table_elements, selected_filter);
                        //     pricing_table_wrapper.removeClass('is-switched');
                        // } else {
                            pricing_table_wrapper.addClass('is-switched').eq(0).one('webkitAnimationEnd oanimationend msAnimationEnd animationend', function() {
                                hide_not_selected_items(table_elements, selected_filter);
                                pricing_table_wrapper.removeClass('is-switched');
                                //change rotation direction if .cd-pricing-list has the .cd-bounce-invert class
                                if(pricing_table.find('.cd-pricing-list').hasClass('cd-bounce-invert')) pricing_table_wrapper.toggleClass('reverse-animation');
                            });
                        // }
                    });
                });
            }
            function show_selected_items(selected_elements) {
                selected_elements.addClass('is-selected');
            }

            function hide_not_selected_items(table_containers, filter) {
                $.each(table_containers, function(key, value){
                    if ( key != filter ) {
                        $(this).removeClass('is-visible is-selected').addClass('is-hidden');

                    } else {
                        $(this).addClass('is-visible').removeClass('is-hidden is-selected');
                    }
                });
            }
        });
    </script>
<?php
}